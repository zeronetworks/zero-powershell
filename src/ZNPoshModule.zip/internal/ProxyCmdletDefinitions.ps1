
# ----------------------------------------------------------------------------------
# Work: Zero Networks PowerShell Module License: Zero Networks PowerShell Module TERMS AND CONDITIONS FOR USE, REPRODUCTION,
# AND DISTRIBUTION
# 1. Definitions.
# "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9
# of this document.
# "Licensor" shall mean Zero Networks Ltd., the copyright owner, and any entity authorized by the copyright owner that is
# granting the License.
# "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are
# under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect,
# to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent
# (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.
# "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.
# "Source" form shall mean the preferred form for making modifications, including but not limited to software source code,
# documentation source, and configuration files.
# "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but
# not limited to compiled object code, generated documentation, and conversions to other media types.
# "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated
# by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).
# "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and
# for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original
# work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from,
# or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.
# "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions
# to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright
# owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this
# definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives,
# including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking
# systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work.
# "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received
# by Licensor and subsequently incorporated within the Work.
# 2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You
# a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative
# Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or
# Object form.
# 3. Grant of License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual,
# worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) license to make, have
# made, use, import, and otherwise transfer free of charge the Work. For clarification purposes, the License does not grant
# You the right to sale the Work or to make any commercial use of the Work.
# 4. If You institute litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the
# Work or a Contribution incorporated within the Work constitutes direct or contributory intellectual property infringement,
# then any licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.
# 5. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or
# without modifications, and in Source or Object form, provided that You meet the following conditions:
# (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and
# (b) You must cause any modified files to carry prominent notices stating that You changed the files; and
# (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and
# attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative
# Works; and
# (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute
# must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that
# do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed
# as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or,
# within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents
# of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices
# within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that
# such additional attribution notices cannot be construed as modifying the License.
# You may add Your own copyright statement to Your modifications and may provide additional or different license terms and
# conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided
# Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.
# 6. It is hereby agreed and acknowledged that Contributions to the Work can be made exclusively under the terms of this license
# agreement, free of charge, and any use made in such Contributions by any party, including Licensor, may be made under the
# terms of this license agreement.
# 7. Submission of Contributions. Any Contribution intentionally submitted for inclusion in the Work by You to the Licensor
# shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the
# above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor
# regarding such Contributions.
# 8. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names
# of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing
# the content of the NOTICE file.
# 9. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each
# Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
# or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or
# FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing
# the Work and assume any risks associated with Your exercise of permissions under this License.
# 10. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or
# otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall
# any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages
# of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited
# to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages
# or losses), even if such Contributor has been advised of the possibility of such damages.
# 11. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose
# to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights
# consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole
# responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor
# harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such
# warranty or additional liability.
# 12. Licensor may change the terms of this License from time to time, at its own discretion, by publishing the amended License
# or a notice notifying of such changes, on the same place where this License is published by Licensor. Your continued use
# of the Work after the changes have been implemented will constitute Your acceptance of the changes.
# END OF TERMS AND CONDITIONS
# ----------------------------------------------------------------------------------

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$cgroup = Get-ZNCustomGroup | where {$_.Name -eq "test2"}
Add-ZNCustomGroupsMember -GroupId $cgroup.Id -MembersId (Search-ZNAsset -Fqdn dc1.zero.labs)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ICustomGroupMembersBody>: .
  MembersId <String[]>: members id

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/add-zncustomgroupsmember
#>
function Add-ZNCustomGroupsMember {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Add', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Add', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(ParameterSetName='AddViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='AddViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Add', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='AddViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='AddViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # members id
    ${MembersId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Add = 'ZN.Api.private\Add-ZNCustomGroupsMember_Add';
            AddViaIdentity = 'ZN.Api.private\Add-ZNCustomGroupsMember_AddViaIdentity';
            AddViaIdentityExpanded = 'ZN.Api.private\Add-ZNCustomGroupsMember_AddViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znassetanalysisexport
#>
function Get-ZNAssetAnalysisExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetAnalysisExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNAssetAnalysisExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with asset analysis data.
.Description
Returns an object with asset analysis data.
.Example
Get-ZNAssetAnalysis -AssetId a:a:ZgBWOMyc

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetAnalysisItems
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znassetanalysis
#>
function Get-ZNAssetAnalysis {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetAnalysisItems], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # connnection state for the query
    ${Connectionstate},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # direction for the query
    ${Direction},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # startTime in epoch(ms)
    ${From},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # sort for the query
    ${Sort},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # endTime in epoch(ms)
    ${To},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNAssetAnalysis_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the asset.
.Description
Returns a list of audits for the asset.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znassetaudit
#>
function Get-ZNAssetAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNAssetAudit_GetViaIdentity';
        }
        if (('GetViaIdentity') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the asset is a member of.
.Description
Returns a list of groups the asset is a member of.
.Example
Get-ZNAssetMemberOf -AssetId a:a:ZgBWOMyc

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znassetmemberof
#>
function Get-ZNAssetMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNAssetMemberOf_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of tags for an entity.
.Description
Returns a list of tags for an entity.
.Example
Get-ZNAssetTag -AssetId a:a:ZgBWOMyc

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znassettag
#>
function Get-ZNAssetTag {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNAssetTag_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an asset.
.Description
Returns the properties of an asset.
.Example
(Get-ZNAsset).Items
.Example
(Get-ZNAsset -Offset 20).Items
.Example
Get-ZNAsset -AssetId a:a:ZgBWOMyc

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAsset
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znasset
#>
function Get-ZNAsset {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAsset], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNAsset_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znauditexport
#>
function Get-ZNAuditExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAuditExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNAuditExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the group.
.Description
Returns a list of audits for the group.
.Example
(Get-ZNGroupAudit -GroupId g:c:gP9POclU).Items

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zngroupaudit
#>
function Get-ZNGroupAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNGroupAudit_GetViaIdentity';
        }
        if (('GetViaIdentity') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the group is a member of.
.Description
Returns a list of groups the group is a member of.
.Example
Get-ZNGroupMemberOf -GroupId g:c:gP9POclU

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zngroupmemberof
#>
function Get-ZNGroupMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNGroupMemberOf_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zngroupsexport
#>
function Get-ZNGroupsExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNGroupsExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNGroupsExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an group.
.Description
Returns the properties of an group.
.Example
Get-ZNGroup
.Example
Get-ZNGroup -offset 10
.Example
Get-ZNGroup -Search Test

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zngroup
#>
function Get-ZNGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNGroup_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrulesexport
#>
function Get-ZNInboundAllowRulesExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNInboundAllowRulesExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNInboundAllowRulesExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an Inbound Allow rule.
.Description
Returns the properties of an Inbound Allow rule.
.Example
Get-ZNInboundAllowRule
.Example
Get-ZNInboundAllowRule -RuleId "be2bdc05-7837-4125-88ba-983e3ff7e763"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrule
#>
function Get-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNInboundAllowRule_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrulesexport
#>
function Get-ZNInboundBlockRulesExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNInboundBlockRulesExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNInboundBlockRulesExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the Inbound Block rule.
.Description
Returns the properties of the Inbound Block rule.
.Example
Get-ZNInboundBlockRule
.Example
Get-ZNInboundBlockRule -RuleId "9f3503cf-02ce-4231-b167-c9e2a2446311"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrule
#>
function Get-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNInboundBlockRule_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a inbound MFA policy object.
.Description
Returns a inbound MFA policy object.
.Example
Get-ZNMfaInboundPolicy
.Example
Get-ZNMfaInboundPolicy -ReactivePolicyId "f68d322c-1cb0-451d-aff2-c920a1a17333"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpolicy
#>
function Get-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNMfaInboundPolicy_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an outbound MFA policy.
.Description
Returns the properties of an outbound MFA policy.
.Example
Get-ZNOutboundBlockRule
.Example
Get-ZNMfaOutboundPolicy -ReactivePolicyId "cff54715-454b-4309-9b70-3055d80a8379"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpolicy
#>
function Get-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNMfaOutboundPolicy_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znnetworkactivitiesexport
#>
function Get-ZNNetworkActivitiesExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNNetworkActivitiesExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNNetworkActivitiesExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrulesexport
#>
function Get-ZNOutboundAllowRulesExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNOutboundAllowRulesExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNOutboundAllowRulesExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an Outbound Allow rule.
.Description
Returns the properties of an Outbound Allow rule.
.Example
Get-ZNOutboundAllowRule
.Example
 Get-ZNOutboundAllowRule -RuleId "c551b646-75d1-477d-8023-367461883fd7"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrule
#>
function Get-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNOutboundAllowRule_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrulesexport
#>
function Get-ZNOutboundBlockRulesExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNOutboundBlockRulesExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNOutboundBlockRulesExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an outbound block rule.
.Description
Returns the properties of an outbound block rule.
.Example
Get-ZNOutboundBlockRule
.Example
Get-ZNOutboundBlockRule -RuleId "0faafa72-2540-4d55-9418-ed62472e0e2d"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrule
#>
function Get-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNOutboundBlockRule_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with rules distribution.
.Description
Returns an object with rules distribution.
.Example
Get-ZNRulesDistribution -RuleId 2f9fd777-d735-4cac-99c5-5f822318e510 -RuleDirection 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDistribution
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znrulesdistribution
#>
function Get-ZNRulesDistribution {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDistribution], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # direction of the rule (1-Inbound, 2-Outbound)
    ${RuleDirection},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNRulesDistribution_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the previous version of the rule.
.Description
Returns the properties of the previous version of the rule.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IHistoryRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znruleshistory
#>
function Get-ZNRulesHistory {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IHistoryRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # version
    ${UpdateId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNRulesHistory_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNRulesHistory_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the user.
.Description
Returns a list of audits for the user.
.Example
Get-ZNUserAudit -UserId u:a:E6iXCia4

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znuseraudit
#>
function Get-ZNUserAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNUserAudit_GetViaIdentity';
        }
        if (('GetViaIdentity') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the user is a member of.
.Description
Returns a list of groups the user is a member of.
.Example
Get-ZNUserMemberOf -UserId u:a:E6iXCia4

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znusermemberof
#>
function Get-ZNUserMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNUserMemberOf_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a csv file to be downloaded.
.Description
Returns a csv file to be downloaded.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znusersexport
#>
function Get-ZNUsersExport {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # exportId to download
    ${ExportId},

    [Parameter(ParameterSetName='GetViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Path to write output file to
    ${OutFile},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNUsersExport_Get';
            GetViaIdentity = 'ZN.Api.private\Get-ZNUsersExport_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an user.
.Description
Returns the properties of an user.
.Example
Get-ZNUser
.Example
 Get-ZNUser -Offset 10
.Example
Get-ZNUser -Search Administrator

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUser
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/get-znuser
#>
function Get-ZNUser {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUser], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='GetViaIdentity', PositionalBinding=$false)]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            GetViaIdentity = 'ZN.Api.private\Get-ZNUser_GetViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Challenge API to get token
.Description
Challenge API to get token
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IChallengeBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IChallengeResponse
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IChallengeBody>: .
  [ChallengeMediumType <String>]: 
  [Email <String>]: 
  [SendSkip <Boolean?>]: 
.Link
https://github.com/zeronetworkszn.api/invoke-znauthchallenge
#>
function Invoke-ZNAuthChallenge {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IChallengeResponse], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='PostExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Post', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IChallengeBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${ChallengeMediumType},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Email},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${SendSkip},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Post = 'ZN.Api.private\Invoke-ZNAuthChallenge_Post';
            PostExpanded = 'ZN.Api.private\Invoke-ZNAuthChallenge_PostExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Login to get token
.Description
Login to get token
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILoginBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILoginResponse
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ILoginBody>: .
  [ChallengeMediumType <String>]: 
  [Email <String>]: 
  [Otp <String>]: 
.Link
https://github.com/zeronetworkszn.api/invoke-znauthlogin
#>
function Invoke-ZNAuthLogin {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILoginResponse], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='PostExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Post', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILoginBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${ChallengeMediumType},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Email},

    [Parameter(ParameterSetName='PostExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Otp},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Post = 'ZN.Api.private\Invoke-ZNAuthLogin_Post';
            PostExpanded = 'ZN.Api.private\Invoke-ZNAuthLogin_PostExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of MFA policies that would match the simulaton.
.Description
Returns a list of MFA policies that would match the simulaton.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOrderedReactivePoliciesList
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

SIMULATIONPARAMS <IComponents1Tw47WoParametersSimulationparameterSchema>: Set of properties to run for the MFA simulation
  [DstAssetId <String>]: 
  [DstProcess <String>]: 
  [Port <String>]: 
  [ProtocolType <String>]: 
  [SrcAssetId <String>]: 
  [SrcProcess <String>]: 
  [SrcUserId <String>]: 
.Link
https://github.com/zeronetworkszn.api/invoke-znsimulatemfainboundpolicy
#>
function Invoke-ZNSimulateMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOrderedReactivePoliciesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Simulate', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IComponents1Tw47WoParametersSimulationparameterSchema]
    # Set of properties to run for the MFA simulation
    # To construct, see NOTES section for SIMULATIONPARAMS properties and create a hash table.
    ${SimulationParams},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Simulate = 'ZN.Api.private\Invoke-ZNSimulateMfaInboundPolicy_Simulate';
        }
        if (('Simulate') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of outbound MFA policies that would match the simulation.
.Description
Returns a list of outbound MFA policies that would match the simulation.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOrderedReactivePoliciesList
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

SIMULATIONPARAMS <IComponents1Tw47WoParametersSimulationparameterSchema>: Set of properties to run for the MFA simulation
  [DstAssetId <String>]: 
  [DstProcess <String>]: 
  [Port <String>]: 
  [ProtocolType <String>]: 
  [SrcAssetId <String>]: 
  [SrcProcess <String>]: 
  [SrcUserId <String>]: 
.Link
https://github.com/zeronetworkszn.api/invoke-znsimulatemfaoutboundpolicy
#>
function Invoke-ZNSimulateMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOrderedReactivePoliciesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Simulate', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IComponents1Tw47WoParametersSimulationparameterSchema]
    # Set of properties to run for the MFA simulation
    # To construct, see NOTES section for SIMULATIONPARAMS properties and create a hash table.
    ${SimulationParams},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Simulate = 'ZN.Api.private\Invoke-ZNSimulateMfaOutboundPolicy_Simulate';
        }
        if (('Simulate') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Add a secondary AD settings in Asset Managment
.Description
Add a secondary AD settings in Asset Managment
.Example
New-ZNAdSecondarySetting -DomainId newdomain.zero.labs -Dc dc1.newdomain.zero.labs

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoSecondaryBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsAdInfoSecondaryBody>: .
  Dc <String>: The domain controller

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/new-znadsecondarysetting
#>
function New-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Create', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The fqdn of the domain
    ${DomainId},

    [Parameter(ParameterSetName='CreateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='CreateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Create', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='CreateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoSecondaryBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='CreateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The domain controller
    ${Dc},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNAdSecondarySetting_Create';
            CreateViaIdentity = 'ZN.Api.private\New-ZNAdSecondarySetting_CreateViaIdentity';
            CreateViaIdentityExpanded = 'ZN.Api.private\New-ZNAdSecondarySetting_CreateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the assetId of the created Linux asset.
.Description
Returns the assetId of the created Linux asset.
.Example
New-ZNAssetsLinux -DisplayName "linuxservera" -Fqdn "linuxservera.zero.labs"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILinuxBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetId
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ILinuxBody>: .
  DisplayName <String>: 
  Fqdn <String>: 
.Link
https://github.com/zeronetworkszn.api/new-znassetslinux
#>
function New-ZNAssetsLinux {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetId], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ILinuxBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNAssetsLinux_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
New-ZNAssetsOt -DisplayName webcam2 -Ipv4 "192.168.10.30" -Type 4 

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOtAssetBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IOtAssetBody>: otAssetBody
  DisplayName <String>: 
  Ipv4 <String>: 
  Type <Single>: 
.Link
https://github.com/zeronetworkszn.api/new-znassetsot
#>
function New-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOtAssetBody]
    # otAssetBody
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNAssetsOt_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
New-ZNCustomGroup -Name "test3" -Description "test custom group"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ICustomGroupBody>: .
  Name <String>: 
  [Description <String>]: 
  [MembersId <String[]>]: members id
.Link
https://github.com/zeronetworkszn.api/new-zncustomgroup
#>
function New-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNCustomGroup_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Create an identity provider settings in Identity Providers
.Description
Create an identity provider settings in Identity Providers
.Example
New-ZNIdpSetting  -IdentityProvider "azure" -SloUrl "https://login.microsoftonline.com/d6eebbdd-d77c-465e-b008-4339027b4006/saml2" -SsoUrl "https://login.microsoftonline.com/d6eebbdd-d77c-465e-b008-4339027b4006/saml2" -IsDefault:$false -Certificate 'MIIC...'

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsIdpBody>: .
  Certificate <String>: Identity Provider certificate
  IdentityProvider <String>: 
  IsDefault <Boolean>: Set as the default authentication method
  SloUrl <String>: Single Log out url
  SsoUrl <String>: Single sign on url
.Link
https://github.com/zeronetworkszn.api/new-znidpsetting
#>
function New-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNIdpSetting_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Inbound Allow rule.
.Description
Returns the properties of the created Inbound Allow rule.
.Example
$portsList = New-ZNPortsList -Protocol TCP -Ports "44,45"
$source = (Get-ZNInboundAllowRulesSourceCandidate -search "any asset").Items
$destination = (Get-ZNInboundAllowRulesDestinationCandidate -Search FS1).Items
New-ZNInboundAllowRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 
.Link
https://github.com/zeronetworkszn.api/new-zninboundallowrule
#>
function New-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNInboundAllowRule_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Inbound Block rule.
.Description
Returns the properties of the created Inbound Block rule.
.Example
$portsList = New-ZNPortsList -Protocol Any
$source = (Get-ZNInboundBlockRulesSourceCandidate -Search "win7").Items
$destination = (Get-ZNInboundBlockRulesDestinationCandidate -Search "all protected Assets").Items
New-ZNInboundBlockRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 
.Link
https://github.com/zeronetworkszn.api/new-zninboundblockrule
#>
function New-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNInboundBlockRule_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the inbound MFA policy after creation.
.Description
Returns the properties of the inbound MFA policy after creation.
.Example
$destination = (Get-ZNMfaInboundPoliciesDestinationCandidate -Search "linuxserver").Items
$source = (Get-ZNMfaInboundPoliciesSourceCandidate -search "Any Asset").Items
$sourceEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcEntityInfosItem]::new()
$sourceEntity.Id = $source.Id
$sourceUser = (Get-ZNMfaInboundPoliciesSourceUserCandidate -search "Any User").Items
$sourceUserEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcUserInfosItem]::new()
$sourceUserEntity.Id = $sourceUser.Id
New-ZNMfaInboundPolicy -DstEntityInfoId $destination.Id -DstPort "22" -DstProcessNames @("*") -FallbackToLoggedOnUser -MfaMethods @(4) -ProtocolType 6 -RuleDuration 6 -SrcEntityInfos @($sourceEntity) -SrcProcessNames @("*") -SrcUserInfos @($sourceUserEntity) -RuleCreationMode 1 -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IReactivePolicyInboundBody>: .
  AdditionalPortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  DstEntityInfoId <String>: 
  DstPort <String>: 
  DstProcessNames <String[]>: 
  FallbackToLoggedOnUser <Boolean>: 
  MfaMethods <Int32[]>: 
  ProtocolType <Int32>: 
  RuleDuration <Int32>: 
  SrcEntityInfos <IReactivePolicyInboundBodySrcEntityInfosItem[]>: 
    Id <String>: 
  SrcProcessNames <String[]>: 
  SrcUserInfos <IReactivePolicyInboundBodySrcUserInfosItem[]>: 
    Id <String>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
.Link
https://github.com/zeronetworkszn.api/new-znmfainboundpolicy
#>
function New-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNMfaInboundPolicy_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a the properties of outbound MFA policy created.
.Description
Returns a the properties of outbound MFA policy created.
.Example
$destination = (Get-ZNMfaOutboundPoliciesDestinationCandidate -Search "switch01").Items
$source = (Get-ZNMfaOutboundPoliciesSourceCandidate -search "All Protected Assets").Items
$sourceEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcEntityInfosItem]::new()
$sourceEntity.Id = $source.Id
$sourceUser = (Get-ZNMfaInboundPoliciesSourceUserCandidate -search "Any User").Items
$sourceUserEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcUserInfosItem]::new()
$sourceUserEntity.Id = $sourceUser.Id
New-ZNMfaOutboundPolicy -DstEntityInfoId $destination.Id -DstPort "22" -FallbackToLoggedOnUser -MfaMethods @(4) -ProtocolType 6 -RuleDuration 6 -SrcEntityInfos @($sourceEntity) -SrcProcessNames @("*") -SrcUserInfos @($sourceUserEntity) -RuleCreationMode 1 -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IReactivePolicyOutboundBody>: .
  AdditionalPortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  DstEntityInfoId <String>: 
  DstPort <String>: 
  DstProcessNames <String[]>: 
  FallbackToLoggedOnUser <Boolean>: 
  MfaMethods <Int32[]>: 
  ProtocolType <Int32>: 
  RuleDuration <Int32>: 
  SrcEntityInfos <IReactivePolicyOutboundBodySrcEntityInfosItem[]>: 
    Id <String>: 
  SrcProcessNames <String[]>: 
  SrcUserInfos <IReactivePolicyOutboundBodySrcUserInfosItem[]>: 
    Id <String>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
.Link
https://github.com/zeronetworkszn.api/new-znmfaoutboundpolicy
#>
function New-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNMfaOutboundPolicy_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Outbound Allow rule.
.Description
Returns the properties of the created Outbound Allow rule.
.Example
$portsList = New-ZNPortsList -Protocol TCP -Ports "53"
$source = (Get-ZNOutboundAllowRulesSourceCandidate -search "all protected assets").Items
$destination = Invoke-ZNEncodeEntityIp -IP 8.8.8.8
New-ZNOutboundAllowRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 
.Link
https://github.com/zeronetworkszn.api/new-znoutboundallowrule
#>
function New-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNOutboundAllowRule_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created outbound block rule.
.Description
Returns the properties of the created outbound block rule.
.Example
$portsList = New-ZNPortsList -Protocol Any
$source = (Get-ZNOutboundAllowRulesSourceCandidate -search "all protected assets").Items
$destination = Invoke-ZNEncodeEntityIp -IP 1.2.3.4 #MalicousIP
New-ZNOutboundBlockRule -LocalEntityId $source.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($destination) -State 1

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 
.Link
https://github.com/zeronetworkszn.api/new-znoutboundblockrule
#>
function New-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNOutboundBlockRule_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the protection policy that was created.
.Description
Returns the protection policy that was created.
.Example
# There are multiple groups with Domain Controllers in the name
$group = Get-ZNADGroup -Search "Domain Controllers" | where {$_.Name -eq "Domain Controllers"}
New-ZNProtectionPolicy -GroupId $group.Id -MinQueueDays 30 -InitialQueueDays 30

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicyBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IProtectionPolicyBody>: .
  GroupId <String>: 
  InitialQueueDays <Int32>: 
  MinQueueDays <Int32>: 
  [Description <String>]: 
.Link
https://github.com/zeronetworkszn.api/new-znprotectionpolicy
#>
function New-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Create', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicyBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Create = 'ZN.Api.private\New-ZNProtectionPolicy_Create';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty reponse.
.Description
Returns an empty reponse.
.Example
Remove-ZNAdSecondarySetting -DomainId newdomain.zero.labs

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znadsecondarysetting
#>
function Remove-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNAdSecondarySetting_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znassetsot
#>
function Remove-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Delete', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter(ParameterSetName='DeleteViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNAssetsOt_Delete';
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNAssetsOt_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Remove-ZNCustomGroupsMember -GroupId "g:c:gP9POclU" -MembersId "a:a:GnyWAsYs"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ICustomGroupMembersBody>: .
  MembersId <String[]>: members id

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-zncustomgroupsmember
#>
function Remove-ZNCustomGroupsMember {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNCustomGroupsMember_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Remove-ZNCustomGroup -GroupId "g:c:h8I6V0TB"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-zncustomgroup
#>
function Remove-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNCustomGroup_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty reponse.
.Description
Returns an empty reponse.
.Example
Remove-ZNIdpSetting -IdentityProviderId azure

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znidpsetting
#>
function Remove-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNIdpSetting_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNInboundAllowRule | where {$_.Description -eq "Test Rule A"}
Remove-ZNInboundAllowRule -RuleId $rule.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-zninboundallowrule
#>
function Remove-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNInboundAllowRule_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNInboundBlockRule | where {$_.Description -eq "Test Rule"}
Remove-ZNInboundBlockRule -RuleId $rule.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-zninboundblockrule
#>
function Remove-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNInboundBlockRule_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$policy = Get-ZNMfaInboundPolicy | where {$_.Description -eq "Test Policy"}
Remove-ZNMfaInboundPolicy -ReactivePolicyId $policy.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znmfainboundpolicy
#>
function Remove-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNMfaInboundPolicy_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$policy = Get-ZNMfaOutboundPolicy | where {$_.Description -eq "Test Policy"}
Remove-ZNMfaOutboundPolicy -ReactivePolicyId $policy.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znmfaoutboundpolicy
#>
function Remove-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNMfaOutboundPolicy_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNOutboundAllowRule | where {$_.Description -eq "Test Rule"}
Remove-ZNOutboundAllowRule -RuleId $rule.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znoutboundallowrule
#>
function Remove-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNOutboundAllowRule_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNOutboundBlockRule | where {$_.Description -eq "Test Rule"}
Remove-ZNOutboundBlockRule -RuleId $rule.Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znoutboundblockrule
#>
function Remove-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNOutboundBlockRule_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and empty object.
.Description
Returns and empty object.
.Example
Remove-ZNProtectionPolicy -ProtectionPolicyId "25b60e5f-3201-48b0-8f04-3df5eb4e2948"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-znprotectionpolicy
#>
function Remove-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteViaIdentity', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            DeleteViaIdentity = 'ZN.Api.private\Remove-ZNProtectionPolicy_DeleteViaIdentity';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the Activities settings in Data Collection
.Description
Update the Activities settings in Data Collection
.Example
Update-ZNActivitiesSetting -ShouldFilterExternalTraffic:$false

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsActivitiesBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsActivitiesBody>: .
  PrivateNetworksList <String[]>: Collection of IP subnets that are internal
  ShouldFilterExternalTraffic <Boolean>: Disable/Enable external traffic collection
.Link
https://github.com/zeronetworkszn.api/update-znactivitiessetting
#>
function Update-ZNActivitiesSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsActivitiesBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNActivitiesSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update a secondary AD settings in Asset Managment
.Description
Update a secondary AD settings in Asset Managment
.Example
Update-ZNAdSecondarySetting -dc dc2.newdomain.zero.labs -DomainId newdomain.zero.labs

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoSecondaryBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsAdInfoSecondaryBody>: .
  Dc <String>: The domain controller

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/update-znadsecondarysetting
#>
function Update-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The fqdn of the domain
    ${DomainId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoSecondaryBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The domain controller
    ${Dc},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNAdSecondarySetting_Update';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNAdSecondarySetting_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNAdSecondarySetting_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set the AD settings in Asset Managment
.Description
Set the AD settings in Asset Managment
.Example
Update-ZNAdSetting -Domain zero.labs -DomainControllerFqdn dc1.zero.labs -Username znremotemanagement -Password "password" -UseLdaps:$false

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsAdInfoBody>: .
  Domain <String>: FQDN of the AD domain
  DomainControllerFqdn <String>: Domain Controller from AD Domain
  Password <String>: Service Acount Password
  UseLdaps <Boolean>: Use LDAP or LDAPs
  Username <String>: Service Account for Zero Networks
.Link
https://github.com/zeronetworkszn.api/update-znadsetting
#>
function Update-ZNAdSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Put', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfoBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Put = 'ZN.Api.private\Update-ZNAdSetting_Put';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Set AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Update-ZNAiExclusionNetworkServer -Icmp -ProcessesList @()  -TcpPorts "" -UdpPorts ""
.Example
$aiSettings = Get-ZNAiExclusionNetworkServer
Update-ZNAiExclusionNetworkServer -Icmp:$aiSettings.Icmp -ProcessesList $aiSettings.ProcessesList  -TcpPorts ($aiSettings.TcpPorts += "443") -UdpPorts $aiSettings.UdpPorts

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAiExclusionInfo>: .
  [Icmp <Boolean?>]: 
  [ProcessesList <String[]>]: 
  [TcpPorts <String>]: 
  [UdpPorts <String>]: 
.Link
https://github.com/zeronetworkszn.api/update-znaiexclusionnetworkserver
#>
function Update-ZNAiExclusionNetworkServer {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Put', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Put = 'ZN.Api.private\Update-ZNAiExclusionNetworkServer_Put';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the Ansible settings in Asset Managment
.Description
Get the Ansible settings in Asset Managment
.Example
Update-ZNAnsibleSetting -ClientId "clientId" -CredentialsName ssh -DisableCertificateValidation:$false -Password "password" -Url "https:1.2.3.4" -Username "ZNAccess"
.Example
$ansible = Get-ZNAnsibleSetting
Update-ZNAnsibleSetting -ClientId $ansible.ClientId -CredentialsName $ansible.CredentialsName -DisableCertificateValidation:$ansible.DisableCertificateValidation -Password "newpassword" -Url $ansible.Url -Username $ansible.Username -ClientSecret "clientSecret"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsibleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsAnsibleBody>: .
  ClientId <String>: OAuth Client Id
  ClientSecret <String>: OAuth Client Secret
  CredentialsName <String>: Name of the creds used to instruct Ansible to connect to linux machines
  DisableCertificateValidation <Boolean>: Control certificate validation
  Password <String>: password to access Ansible API
  Url <String>: URL of the Ansible server
  Username <String>: username to access Ansible API.
.Link
https://github.com/zeronetworkszn.api/update-znansiblesetting
#>
function Update-ZNAnsibleSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsibleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNAnsibleSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Edit OT-IoT asset
.Description
Edit OT-IoT asset
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOtAssetEditBody
.Outputs
System.Boolean
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IOtAssetEditBody>: otAssetEditBody
  DisplayName <String>: 
  Type <Single>: 
.Link
https://github.com/zeronetworkszn.api/update-znassetot
#>
function Update-ZNAssetOt {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='Put', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IOtAssetEditBody]
    # otAssetEditBody
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Put = 'ZN.Api.private\Update-ZNAssetOt_Put';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Update-ZNCustomGroup -GroupId g:c:DtglBTHi -Description "updated desccription"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ICustomGroupBody>: .
  Name <String>: 
  [Description <String>]: 
  [MembersId <String[]>]: members id

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/update-zncustomgroup
#>
function Update-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Name},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # members id
    ${MembersId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNCustomGroup_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNCustomGroup_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNCustomGroup_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNCustomGroup_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the Default SSO Application settings in Identity Providers
.Description
Update the Default SSO Application settings in Identity Providers
.Example
Update-ZNDefaultApplicationSetting -Application 2

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpDefaultApplicationBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsIdpDefaultApplicationBody>: .
  Application <Int32>: 1-Admin Portal, 2-Access Portal
.Link
https://github.com/zeronetworkszn.api/update-zndefaultapplicationsetting
#>
function Update-ZNDefaultApplicationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpDefaultApplicationBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNDefaultApplicationSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Firewall settings.
.Description
Returns the properties of the updated Firewall settings.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsFirewallBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsFirewallBody>: .
  ImplicitIcmpRuleEnabled <Boolean>: 
.Link
https://github.com/zeronetworkszn.api/update-znfirewallsetting
#>
function Update-ZNFirewallSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsFirewallBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNFirewallSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update identity provider settings in Identity Providers
.Description
Update identity provider settings in Identity Providers
.Example
$azure = Get-ZNIdpSetting | where {$_.IdentityProviderType -eq "azure"}
Update-ZNIdpSetting -IdentityProviderId $azure.IdentityProviderType -Certificate $azure.Certificate -IdentityProvider $azure.IdentityProviderType -SloUrl $azure.SloUrl -SsoUrl $azure.SsoUrl -IsDefault

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsIdpBody>: .
  Certificate <String>: Identity Provider certificate
  IdentityProvider <String>: 
  IsDefault <Boolean>: Set as the default authentication method
  SloUrl <String>: Single Log out url
  SsoUrl <String>: Single sign on url

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/update-znidpsetting
#>
function Update-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # Identity provider Id
    ${IdentityProviderId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdpBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Identity Provider certificate
    ${Certificate},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${IdentityProvider},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Set as the default authentication method
    ${IsDefault},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single Log out url
    ${SloUrl},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single sign on url
    ${SsoUrl},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNIdpSetting_Update';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNIdpSetting_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNIdpSetting_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the update Inbound Allow rule.
.Description
Returns the properties of the update Inbound Allow rule.
.Example
#Get the Rule
$rule = Get-ZNInboundAllowRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList = (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNInboundAllowRule -RuleId $rule.id -RemoteEntityIdsList $rule.RemoteEntityIdsList

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/update-zninboundallowrule
#>
function Update-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNInboundAllowRule_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNInboundAllowRule_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNInboundAllowRule_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNInboundAllowRule_UpdateViaIdentityExpanded';
        }
        if (('UpdateExpanded', 'UpdateViaIdentityExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Inbound Block rule.
.Description
Returns the properties of the updated Inbound Block rule.
.Example
#Get the Rule
$rule = Get-ZNInboundBlockRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList = (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNInboundBlockRule -RuleId $rule.id -RemoteEntityIdsList $rule.RemoteEntityIdsList

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/update-zninboundblockrule
#>
function Update-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNInboundBlockRule_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNInboundBlockRule_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNInboundBlockRule_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNInboundBlockRule_UpdateViaIdentityExpanded';
        }
        if (('UpdateExpanded', 'UpdateViaIdentityExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the upddated properties of JAMF Credentials settings.
.Description
Returns the upddated properties of JAMF Credentials settings.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentialsBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsJamfCredentialsBody>: .
  Host <String>: JAMF url
  Password <String>: JAMF Password
  Username <String>: JAMF username
.Link
https://github.com/zeronetworkszn.api/update-znjamfcredentialssetting
#>
function Update-ZNJamfCredentialsSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentialsBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNJamfCredentialsSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the linux user settings in Asset Managment
.Description
Update the linux user settings in Asset Managment
.Example
Update-ZNLinuxUserSetting -Username zn-admin -Password "NewPassword" -PrivateKey "Key"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsLinuxUserBody
.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsLinuxUserBody>: .
  Password <String>: password for the linux user
  PrivateKey <String>: private key for the linux user
  Username <String>: the linux user name
.Link
https://github.com/zeronetworkszn.api/update-znlinuxusersetting
#>
function Update-ZNLinuxUserSetting {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsLinuxUserBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNLinuxUserSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$mfa = Get-ZNMfaAuthenticationSetting
Update-ZNMfaAuthenticationSetting -IsRequiresAuth:$mfa.ItemIsRequiresAuth -IsSsoForceAuth:$mfa.ItemIsSsoForceAuth -TokenTtl 120

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaAuthenticationBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsMfaAuthenticationBody>: .
  IsRequiresAuth <Boolean>: Authentication Reqiured
  IsSsoForceAuth <Boolean>: Force sso authentication
  TokenTtl <Int32>: Token time to tive in minutes
.Link
https://github.com/zeronetworkszn.api/update-znmfaauthenticationsetting
#>
function Update-ZNMfaAuthenticationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaAuthenticationBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNMfaAuthenticationSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated MFA detection settings.
.Description
Returns the properties of the updated MFA detection settings.
.Example
Update-ZNMfaDetectionSetting -TimeoutMinutes 5

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetectionBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsMfaDetectionBody>: .
  TimeoutMinutes <Int32>: access policy cooldown
.Link
https://github.com/zeronetworkszn.api/update-znmfadetectionsetting
#>
function Update-ZNMfaDetectionSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetectionBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNMfaDetectionSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the inbound MFA policy after updating.
.Description
Returns the properties of the inbound MFA policy after updating.
.Example
#Get the policy
$mfaPolicy = Get-ZNMfaInboundPolicy -ReactivePolicyId e1db180f-e435-498c-ae17-59651f3c3dc3
#add a port
$mfaPolicy.ItemDstPort = $mfaPolicy.ItemDstPort+,",24"
Update-ZNMfaInboundPolicy -ReactivePolicyId $mfaPolicy.ItemId -DstPort $mfaPolicy.ItemDstPort

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

BODY <IReactivePolicyInboundBody>: .
  AdditionalPortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  DstEntityInfoId <String>: 
  DstPort <String>: 
  DstProcessNames <String[]>: 
  FallbackToLoggedOnUser <Boolean>: 
  MfaMethods <Int32[]>: 
  ProtocolType <Int32>: 
  RuleDuration <Int32>: 
  SrcEntityInfos <IReactivePolicyInboundBodySrcEntityInfosItem[]>: 
    Id <String>: 
  SrcProcessNames <String[]>: 
  SrcUserInfos <IReactivePolicyInboundBodySrcUserInfosItem[]>: 
    Id <String>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

SRCENTITYINFOS <IReactivePolicyInboundBodySrcEntityInfosItem[]>: .
  Id <String>: 

SRCUSERINFOS <IReactivePolicyInboundBodySrcUserInfosItem[]>: .
  Id <String>: 
.Link
https://github.com/zeronetworkszn.api/update-znmfainboundpolicy
#>
function Update-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the MFA policy
    ${ReactivePolicyId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstEntityInfoId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstPort},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${DstProcessNames},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${FallbackToLoggedOnUser},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # .
    ${MfaMethods},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${ProtocolType},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${RuleDuration},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBodySrcEntityInfosItem[]]
    # .
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${SrcProcessNames},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBodySrcUserInfosItem[]]
    # .
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNMfaInboundPolicy_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNMfaInboundPolicy_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNMfaInboundPolicy_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNMfaInboundPolicy_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the updated properties of an outbound MFA policy.
.Description
Returns the updated properties of an outbound MFA policy.
.Example
#Get the policy
$mfaPolicy = Get-ZNMfaOutboundPolicy -ReactivePolicyId b307438a-5a02-49a0-a8e3-944c0558f0fe 
#add a port
$mfaPolicy.ItemDstPort = $mfaPolicy.ItemDstPort+,",23"
Update-ZNMfaOutboundPolicy -ReactivePolicyId $mfaPolicy.ItemId -DstEntityInfoId $mfaPolicy.DstEntityInfoId -DstPort $mfaPolicy.ItemDstPort -FallbackToLoggedOnUser:$false -MfaMethods $mfaPolicy.ItemMfaMethods -ProtocolType $mfaPolicy.ItemProtocolType -RuleCreationMode $mfaPolicy.ItemRuleCreationMode -RuleDuration $mfaPolicy.ItemRuleDuration -SrcEntityInfos $mfaPolicy.ItemSrcEntityInfos -SrcProcessNames $mfaPolicy.ItemSrcProcessNames  -SrcUserInfos $mfaPolicy.ItemSrcUserInfos -State $mfaPolicy.ItemState

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

BODY <IReactivePolicyOutboundBody>: .
  AdditionalPortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  DstEntityInfoId <String>: 
  DstPort <String>: 
  DstProcessNames <String[]>: 
  FallbackToLoggedOnUser <Boolean>: 
  MfaMethods <Int32[]>: 
  ProtocolType <Int32>: 
  RuleDuration <Int32>: 
  SrcEntityInfos <IReactivePolicyOutboundBodySrcEntityInfosItem[]>: 
    Id <String>: 
  SrcProcessNames <String[]>: 
  SrcUserInfos <IReactivePolicyOutboundBodySrcUserInfosItem[]>: 
    Id <String>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

SRCENTITYINFOS <IReactivePolicyOutboundBodySrcEntityInfosItem[]>: .
  Id <String>: 

SRCUSERINFOS <IReactivePolicyOutboundBodySrcUserInfosItem[]>: .
  Id <String>: 
.Link
https://github.com/zeronetworkszn.api/update-znmfaoutboundpolicy
#>
function Update-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the MFA policy
    ${ReactivePolicyId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstEntityInfoId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstPort},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${DstProcessNames},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${FallbackToLoggedOnUser},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # .
    ${MfaMethods},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${ProtocolType},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${RuleDuration},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBodySrcEntityInfosItem[]]
    # .
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${SrcProcessNames},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBodySrcUserInfosItem[]]
    # .
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNMfaOutboundPolicy_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNMfaOutboundPolicy_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNMfaOutboundPolicy_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNMfaOutboundPolicy_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the monitored group settings in Asset Managment
.Description
Update the monitored group settings in Asset Managment
.Example
Update-ZNMonitoredGroupSetting -GroupId (Get-ZNMonitoredGroupCandidatesSetting -Search "All AD assets").Items.Id -IsEnabled

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroupBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsMonitoredGroupBody>: .
  GroupId <String>: The groupId for monitoring
  IsEnabled <Boolean>: Enable/Disable monitoring group
.Link
https://github.com/zeronetworkszn.api/update-znmonitoredgroupsetting
#>
function Update-ZNMonitoredGroupSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroupBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNMonitoredGroupSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Mail Notifications settings.
.Description
Returns the properties of the updated Mail Notifications settings.
.Example
Update-ZNNotificationSetting -AssetProtected:$true -AssetQueued:$false -AssetUnprotected:$true

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotificationBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsNotificationBody>: .
  AssetProtected <Boolean>: Notify asset added to protection
  AssetQueued <Boolean>: Notify asset added to learning
  AssetUnprotected <Boolean>: Notify asset removed from protection
.Link
https://github.com/zeronetworkszn.api/update-znnotificationsetting
#>
function Update-ZNNotificationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotificationBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNNotificationSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Outbound Allow rules.
.Description
Returns the properties of the updated Outbound Allow rules.
.Example
#Get the Rule
$rule = Get-ZNOutboundAllowRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList += (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNOutboundAllowRule -RuleId $rule.id -ExpiresAt $rule.ExpiresAt -LocalEntityId $rule.LocalEntityId -LocalProcessesList $rule.LocalProcessesList -PortsList $rule.PortsList -RemoteEntityIdsList $rule.RemoteEntityIdsList -State $rule.State -Description $rule.Description

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/update-znoutboundallowrule
#>
function Update-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNOutboundAllowRule_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNOutboundAllowRule_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNOutboundAllowRule_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNOutboundAllowRule_UpdateViaIdentityExpanded';
        }
        if (('UpdateExpanded', 'UpdateViaIdentityExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated outbound block rule.
.Description
Returns the properties of the updated outbound block rule.
.Example
#Get the Rule
$rule = Get-ZNOutboundBlockRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList += (Invoke-ZNEncodeEntityIP -IP 1.1.1.2)
#Update the rule
Update-ZNOutboundBlockRule -RuleId $rule.id -ExpiresAt $rule.ExpiresAt -LocalEntityId $rule.LocalEntityId -LocalProcessesList $rule.LocalProcessesList -PortsList $rule.PortsList -RemoteEntityIdsList $rule.RemoteEntityIdsList -State $rule.State -Description $rule.Description

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IRuleBody>: .
  ExpiresAt <Int32>: 
  LocalEntityId <String>: 
  LocalProcessesList <String[]>: 
  PortsList <IPortsListItem[]>: 
    [Ports <String>]: 
    [ProtocolType <Int32?>]: 
  RemoteEntityIdsList <String[]>: 
  State <Int32>: 1=Enabled, 2=Disabled
  [Description <String>]: 
  [ExcludedLocalIdsList <String[]>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/update-znoutboundblockrule
#>
function Update-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(ParameterSetName='UpdateExpanded', Mandatory)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(ParameterSetName='UpdateExpanded')]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNOutboundBlockRule_Update';
            UpdateExpanded = 'ZN.Api.private\Update-ZNOutboundBlockRule_UpdateExpanded';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNOutboundBlockRule_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNOutboundBlockRule_UpdateViaIdentityExpanded';
        }
        if (('UpdateExpanded', 'UpdateViaIdentityExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the group that was updated for Protection Automation settings.
.Description
Returns the properties of the group that was updated for Protection Automation settings.
.Example
Update-ZNProtectionAutomationSetting -GroupId (Get-ZNAdGroup -Search ZeroNetworksProtectedAssets).Id

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsProtectionAutomationBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsProtectionAutomationBody>: .
  [GroupId <String>]: Group ID to set
.Link
https://github.com/zeronetworkszn.api/update-znprotectionautomationsetting
#>
function Update-ZNProtectionAutomationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Update', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsProtectionAutomationBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNProtectionAutomationSetting_Update';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the updated settings for the protection policy.
.Description
Returns the updated settings for the protection policy.
.Example
$pp = Get-ZNProtectionPolicy | where {$_.GroupId -eq "g:t:01276c2c"}
Update-ZNProtectionPolicy -ProtectionPolicyId $pp.Id -MinQueueDays 30

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicyUpdateBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IProtectionPolicyUpdateBody>: .
  [MinQueueDays <Int32?>]: 

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/update-znprotectionpolicy
#>
function Update-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateViaIdentityExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Update', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the protection policy
    ${ProtectionPolicyId},

    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Update', Mandatory, ValueFromPipeline)]
    [Parameter(ParameterSetName='UpdateViaIdentity', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicyUpdateBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UpdateViaIdentityExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${MinQueueDays},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Update = 'ZN.Api.private\Update-ZNProtectionPolicy_Update';
            UpdateViaIdentity = 'ZN.Api.private\Update-ZNProtectionPolicy_UpdateViaIdentity';
            UpdateViaIdentityExpanded = 'ZN.Api.private\Update-ZNProtectionPolicy_UpdateViaIdentityExpanded';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set the portal security settings
.Description
Set the portal security settings
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAuthBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ISettingsAuthBody>: settingsAuthBody
  [ItemPortalTokenTtl <Single?>]: Portal session token timeout (in minutes)
.Link
https://github.com/zeronetworkszn.api/update-znsettingsauth
#>
function Update-ZNSettingsAuth {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Put', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAuthBody]
    # settingsAuthBody
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Put = 'ZN.Api.private\Update-ZNSettingsAuth_Put';
        }

        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}
