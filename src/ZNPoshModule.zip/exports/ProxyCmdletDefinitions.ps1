
# ----------------------------------------------------------------------------------
# Work: Zero Networks PowerShell Module License: Zero Networks PowerShell Module TERMS AND CONDITIONS FOR USE, REPRODUCTION,
# AND DISTRIBUTION
# 1. Definitions.
# "License" shall mean the terms and conditions for use, reproduction, and distribution as defined by Sections 1 through 9
# of this document.
# "Licensor" shall mean Zero Networks Ltd., the copyright owner, and any entity authorized by the copyright owner that is
# granting the License.
# "Legal Entity" shall mean the union of the acting entity and all other entities that control, are controlled by, or are
# under common control with that entity. For the purposes of this definition, "control" means (i) the power, direct or indirect,
# to cause the direction or management of such entity, whether by contract or otherwise, or (ii) ownership of fifty percent
# (50%) or more of the outstanding shares, or (iii) beneficial ownership of such entity.
# "You" (or "Your") shall mean an individual or Legal Entity exercising permissions granted by this License.
# "Source" form shall mean the preferred form for making modifications, including but not limited to software source code,
# documentation source, and configuration files.
# "Object" form shall mean any form resulting from mechanical transformation or translation of a Source form, including but
# not limited to compiled object code, generated documentation, and conversions to other media types.
# "Work" shall mean the work of authorship, whether in Source or Object form, made available under the License, as indicated
# by a copyright notice that is included in or attached to the work (an example is provided in the Appendix below).
# "Derivative Works" shall mean any work, whether in Source or Object form, that is based on (or derived from) the Work and
# for which the editorial revisions, annotations, elaborations, or other modifications represent, as a whole, an original
# work of authorship. For the purposes of this License, Derivative Works shall not include works that remain separable from,
# or merely link (or bind by name) to the interfaces of, the Work and Derivative Works thereof.
# "Contribution" shall mean any work of authorship, including the original version of the Work and any modifications or additions
# to that Work or Derivative Works thereof, that is intentionally submitted to Licensor for inclusion in the Work by the copyright
# owner or by an individual or Legal Entity authorized to submit on behalf of the copyright owner. For the purposes of this
# definition, "submitted" means any form of electronic, verbal, or written communication sent to the Licensor or its representatives,
# including but not limited to communication on electronic mailing lists, source code control systems, and issue tracking
# systems that are managed by, or on behalf of, the Licensor for the purpose of discussing and improving the Work.
# "Contributor" shall mean Licensor and any individual or Legal Entity on behalf of whom a Contribution has been received
# by Licensor and subsequently incorporated within the Work.
# 2. Grant of Copyright License. Subject to the terms and conditions of this License, each Contributor hereby grants to You
# a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable copyright license to reproduce, prepare Derivative
# Works of, publicly display, publicly perform, sublicense, and distribute the Work and such Derivative Works in Source or
# Object form.
# 3. Grant of License. Subject to the terms and conditions of this License, each Contributor hereby grants to You a perpetual,
# worldwide, non-exclusive, no-charge, royalty-free, irrevocable (except as stated in this section) license to make, have
# made, use, import, and otherwise transfer free of charge the Work. For clarification purposes, the License does not grant
# You the right to sale the Work or to make any commercial use of the Work.
# 4. If You institute litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the
# Work or a Contribution incorporated within the Work constitutes direct or contributory intellectual property infringement,
# then any licenses granted to You under this License for that Work shall terminate as of the date such litigation is filed.
# 5. Redistribution. You may reproduce and distribute copies of the Work or Derivative Works thereof in any medium, with or
# without modifications, and in Source or Object form, provided that You meet the following conditions:
# (a) You must give any other recipients of the Work or Derivative Works a copy of this License; and
# (b) You must cause any modified files to carry prominent notices stating that You changed the files; and
# (c) You must retain, in the Source form of any Derivative Works that You distribute, all copyright, patent, trademark, and
# attribution notices from the Source form of the Work, excluding those notices that do not pertain to any part of the Derivative
# Works; and
# (d) If the Work includes a "NOTICE" text file as part of its distribution, then any Derivative Works that You distribute
# must include a readable copy of the attribution notices contained within such NOTICE file, excluding those notices that
# do not pertain to any part of the Derivative Works, in at least one of the following places: within a NOTICE text file distributed
# as part of the Derivative Works; within the Source form or documentation, if provided along with the Derivative Works; or,
# within a display generated by the Derivative Works, if and wherever such third-party notices normally appear. The contents
# of the NOTICE file are for informational purposes only and do not modify the License. You may add Your own attribution notices
# within Derivative Works that You distribute, alongside or as an addendum to the NOTICE text from the Work, provided that
# such additional attribution notices cannot be construed as modifying the License.
# You may add Your own copyright statement to Your modifications and may provide additional or different license terms and
# conditions for use, reproduction, or distribution of Your modifications, or for any such Derivative Works as a whole, provided
# Your use, reproduction, and distribution of the Work otherwise complies with the conditions stated in this License.
# 6. It is hereby agreed and acknowledged that Contributions to the Work can be made exclusively under the terms of this license
# agreement, free of charge, and any use made in such Contributions by any party, including Licensor, may be made under the
# terms of this license agreement.
# 7. Submission of Contributions. Any Contribution intentionally submitted for inclusion in the Work by You to the Licensor
# shall be under the terms and conditions of this License, without any additional terms or conditions. Notwithstanding the
# above, nothing herein shall supersede or modify the terms of any separate license agreement you may have executed with Licensor
# regarding such Contributions.
# 8. Trademarks. This License does not grant permission to use the trade names, trademarks, service marks, or product names
# of the Licensor, except as required for reasonable and customary use in describing the origin of the Work and reproducing
# the content of the NOTICE file.
# 9. Disclaimer of Warranty. Unless required by applicable law or agreed to in writing, Licensor provides the Work (and each
# Contributor provides its Contributions) on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
# or implied, including, without limitation, any warranties or conditions of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or
# FITNESS FOR A PARTICULAR PURPOSE. You are solely responsible for determining the appropriateness of using or redistributing
# the Work and assume any risks associated with Your exercise of permissions under this License.
# 10. Limitation of Liability. In no event and under no legal theory, whether in tort (including negligence), contract, or
# otherwise, unless required by applicable law (such as deliberate and grossly negligent acts) or agreed to in writing, shall
# any Contributor be liable to You for damages, including any direct, indirect, special, incidental, or consequential damages
# of any character arising as a result of this License or out of the use or inability to use the Work (including but not limited
# to damages for loss of goodwill, work stoppage, computer failure or malfunction, or any and all other commercial damages
# or losses), even if such Contributor has been advised of the possibility of such damages.
# 11. Accepting Warranty or Additional Liability. While redistributing the Work or Derivative Works thereof, You may choose
# to offer, and charge a fee for, acceptance of support, warranty, indemnity, or other liability obligations and/or rights
# consistent with this License. However, in accepting such obligations, You may act only on Your own behalf and on Your sole
# responsibility, not on behalf of any other Contributor, and only if You agree to indemnify, defend, and hold each Contributor
# harmless for any liability incurred by, or claims asserted against, such Contributor by reason of your accepting any such
# warranty or additional liability.
# 12. Licensor may change the terms of this License from time to time, at its own discretion, by publishing the amended License
# or a notice notifying of such changes, on the same place where this License is published by Licensor. Your continued use
# of the Work after the changes have been implemented will constitute Your acceptance of the changes.
# END OF TERMS AND CONDITIONS
# ----------------------------------------------------------------------------------

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$cgroup = Get-ZNCustomGroup | where {$_.Name -eq "test2"}
Add-ZNCustomGroupsMember -GroupId $cgroup.Id -MembersId (Search-ZNAsset -Fqdn dc1.zero.labs)

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/add-zncustomgroupsmember
#>
function Add-ZNCustomGroupsMember {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='AddExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # members id
    ${MembersId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            AddExpanded = 'ZN.Api.private\Add-ZNCustomGroupsMember_AddExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get Activities settings in Data Collection
.Description
Get Activities settings in Data Collection
.Example
Get-ZNActivitiesSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsActivitiesConfig
.Link
https://github.com/zeronetworkszn.api/get-znactivitiessetting
#>
function Get-ZNActivitiesSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsActivitiesConfig], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNActivitiesSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of AD groups.
.Description
Returns a list of AD groups.
.Example
Get-ZNAdGroup
.Example
Get-ZNAdGroup -offset 10
.Example
Get-ZNAdGroup -Search Administrators

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-znadgroup
#>
function Get-ZNAdGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAdGroup_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
List the secondary AD settings in Asset Managment
.Description
List the secondary AD settings in Asset Managment
.Example
Get-ZNAdSecondarySetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo
.Link
https://github.com/zeronetworkszn.api/get-znadsecondarysetting
#>
function Get-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAdSecondarySetting_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the AD settings in Asset Managment
.Description
Get the AD settings in Asset Managment
.Example
Get-ZNAdSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo
.Link
https://github.com/zeronetworkszn.api/get-znadsetting
#>
function Get-ZNAdSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAdSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get AI network exclusion for clients and servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Get AI network exclusion for clients and servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Get-ZNAiExclusionNetworkBoth

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znaiexclusionnetworkboth
#>
function Get-ZNAiExclusionNetworkBoth {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAiExclusionNetworkBoth_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get AI network exclusion for clients: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Get AI network exclusion for clients: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Get-ZNAiExclusionNetworkClient

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znaiexclusionnetworkclient
#>
function Get-ZNAiExclusionNetworkClient {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAiExclusionNetworkClient_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Get AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Get-ZNAiExclusionNetworkServer

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znaiexclusionnetworkserver
#>
function Get-ZNAiExclusionNetworkServer {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAiExclusionNetworkServer_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get AI source entities to ignore during learning.
.Description
Get AI source entities to ignore during learning.
.Example
Get-ZNAiExclusionSrcEntity

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBasicInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znaiexclusionsrcentity
#>
function Get-ZNAiExclusionSrcEntity {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBasicInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAiExclusionSrcEntity_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a date in epoch(ms) for the next batch of AI rules.
.Description
Returns a date in epoch(ms) for the next batch of AI rules.
.Example
$aiDate = Get-ZNAiNextBatch
(Get-Date -Date "01-01-1970") + ([System.TimeSpan]::FromMilliseconds($ai))

.Outputs
System.Int64
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znainextbatch
#>
function Get-ZNAiNextBatch {
[OutputType([System.Int64], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAiNextBatch_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the Ansible settings in Asset Managment
.Description
Get the Ansible settings in Asset Managment
.Example
Get-ZNAnsibleSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible
.Link
https://github.com/zeronetworkszn.api/get-znansiblesetting
#>
function Get-ZNAnsibleSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAnsibleSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with asset analysis data.
.Description
Returns an object with asset analysis data.
.Example
Get-ZNAssetAnalysis -AssetId a:a:ZgBWOMyc

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetAnalysisItems
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetanalysis
#>
function Get-ZNAssetAnalysis {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetAnalysisItems], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # connnection state for the query
    ${Connectionstate},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # direction for the query
    ${Direction},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # startTime in epoch(ms)
    ${From},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # sort for the query
    ${Sort},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # endTime in epoch(ms)
    ${To},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetAnalysis_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the asset.
.Description
Returns a list of audits for the asset.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetaudit
#>
function Get-ZNAssetAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetAudit_Get';
        }
        if (('Get') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the asset is a member of.
.Description
Returns a list of groups the asset is a member of.
.Example
Get-ZNAssetMemberOf -AssetId a:a:ZgBWOMyc

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-znassetmemberof
#>
function Get-ZNAssetMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetMemberOf_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of assets that are monitored.
.Description
Returns a list of assets that are monitored.
.Example
(Get-ZNAssetsMonitored).Items
.Example
(Get-ZNAssetsMonitored -Offset 10).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsmonitored
#>
function Get-ZNAssetsMonitored {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAssetsMonitored_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of OT/IoT assets.
.Description
Returns a list of OT/IoT assets.
.Example
(Get-ZNAssetsOt).Items
.Example
(Get-ZNAssetsOt -Offset 10).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetOt
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsot
#>
function Get-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetOt], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAssetsOt_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of Protected assets.
.Description
Returns a list of Protected assets.
.Example
(Get-ZNAssetsProtected).Items
.Example
(Get-ZNAssetsProtected -Offset 10).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsprotected
#>
function Get-ZNAssetsProtected {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAssetsProtected_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of assets in Learning.
.Description
Returns a list of assets in Learning.
.Example
(Get-ZNAssetsQueued).Items
.Example
(Get-ZNAssetsQueued -Offset 10).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsqueued
#>
function Get-ZNAssetsQueued {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAssetsQueued_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with asset state statistics.
.Description
Returns an object with asset state statistics.
.Example
Get-ZNAssetsStatesStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetsStatesStatisticsAssetsStatesStatistics
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsstatesstatistics
#>
function Get-ZNAssetsStatesStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetsStatesStatisticsAssetsStatesStatistics], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetsStatesStatistics_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with asset statistics.
.Description
Returns an object with asset statistics.
.Example
Get-ZNAssetsStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetsStatisticsItem
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znassetsstatistics
#>
function Get-ZNAssetsStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetsStatisticsItem], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetsStatistics_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of tags for an entity.
.Description
Returns a list of tags for an entity.
.Example
Get-ZNAssetTag -AssetId a:a:ZgBWOMyc

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-znassettag
#>
function Get-ZNAssetTag {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAssetTag_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an asset.
.Description
Returns the properties of an asset.
.Example
(Get-ZNAsset).Items
.Example
(Get-ZNAsset -Offset 20).Items
.Example
Get-ZNAsset -AssetId a:a:ZgBWOMyc

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAsset
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znasset
#>
function Get-ZNAsset {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAsset], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetList])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # assetId to filter on
    ${AssetId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNAsset_Get';
            List = 'ZN.Api.private\Get-ZNAsset_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audit events.
.Description
Returns a list of audit events.
.Example
(Get-ZNAudit).Items
.Example
$scrollCursor = (Get-ZNAudit).ScrollCursor
(Get-ZNAudit -Cursor $scrollCursor).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znaudit
#>
function Get-ZNAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # entityId to filter on
    ${EntityId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # startTime in epoch(ms)
    ${From},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # endTime in epoch(ms)
    ${To},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNAudit_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of candidates for custom group membership.
.Description
Returns a list of candidates for custom group membership.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-zncustomgroupscandidate
#>
function Get-ZNCustomGroupsCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNCustomGroupsCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of Custom groups.
.Description
Returns a list of Custom groups.
.Example
Get-ZNCustomGroup
.Example
Get-ZNCustomGroup -offset 10
.Example
Get-ZNCustomGroup -Search Test

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-zncustomgroup
#>
function Get-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNCustomGroup_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get Default SSO Application settings in Identity Providers
.Description
Get Default SSO Application settings in Identity Providers
.Example
Get-ZNDefaultApplicationSetting

.Outputs
System.Int32
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zndefaultapplicationsetting
#>
function Get-ZNDefaultApplicationSetting {
[OutputType([System.Int32], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNDefaultApplicationSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of Firewall settings.
.Description
Returns the properties of Firewall settings.
.Example
 Get-ZNFirewallSetting
 ```


.Outputs
System.Boolean
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znfirewallsetting
#>
function Get-ZNFirewallSetting {
[OutputType([System.Boolean], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNFirewallSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the group.
.Description
Returns a list of audits for the group.
.Example
(Get-ZNGroupAudit -GroupId g:c:gP9POclU).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zngroupaudit
#>
function Get-ZNGroupAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNGroupAudit_Get';
        }
        if (('Get') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the group is a member of.
.Description
Returns a list of groups the group is a member of.
.Example
Get-ZNGroupMemberOf -GroupId g:c:gP9POclU

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-zngroupmemberof
#>
function Get-ZNGroupMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNGroupMemberOf_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of potential members for a group.
.Description
Returns a list of potential members for a group.
.Example
$group = Get-ZNAdGroup | where{$_.Name -eq "Administrators"}
(Get-ZNGroupsMember -GroupId $group.id -IncludeNestedMembers:$false).Entities
.Example
$group = Get-ZNAdGroup | where{$_.Name -eq "Administrators"}
(Get-ZNGroupsMember -GroupId $group.id -IncludeNestedMembers:$true).Entities

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IEntitiesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zngroupsmember
#>
function Get-ZNGroupsMember {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IEntitiesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Management.Automation.SwitchParameter]
    # include nested members in the result
    ${IncludeNestedMembers},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNGroupsMember_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with group statistics.
.Description
Returns an object with group statistics.
.Example
Get-ZNGroupsStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupsStatisticsGroupStatistics
.Link
https://github.com/zeronetworkszn.api/get-zngroupsstatistics
#>
function Get-ZNGroupsStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupsStatisticsGroupStatistics], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNGroupsStatistics_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an group.
.Description
Returns the properties of an group.
.Example
Get-ZNGroup
.Example
Get-ZNGroup -offset 10
.Example
Get-ZNGroup -Search Test

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-zngroup
#>
function Get-ZNGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNGroup_Get';
            List = 'ZN.Api.private\Get-ZNGroup_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get identity provider settings in Identity Providers
.Description
Get identity provider settings in Identity Providers
.Example
Get-ZNIdpSetting | FL

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp
.Link
https://github.com/zeronetworkszn.api/get-znidpsetting
#>
function Get-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNIdpSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destionation candidates for Inbound Allow rules.
.Description
Returns a list of destionation candidates for Inbound Allow rules.
.Example
(Get-ZNInboundAllowRulesDestinationCandidate).Items
.Example
(Get-ZNInboundAllowRulesDestinationCandidate -search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrulesdestinationcandidate
#>
function Get-ZNInboundAllowRulesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundAllowRulesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of excluded destionation candidates for Inbound Allow rules.
.Description
Returns a list of excluded destionation candidates for Inbound Allow rules.
.Example
(Get-ZNInboundAllowRulesExcludedDestinationCandidate).Items
.Example
(Get-ZNInboundAllowRulesExcludedDestinationCandidate -search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrulesexcludeddestinationcandidate
#>
function Get-ZNInboundAllowRulesExcludedDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundAllowRulesExcludedDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates for Inbound Allow rules.
.Description
Returns a list of source candidates for Inbound Allow rules.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrulessourcecandidate
#>
function Get-ZNInboundAllowRulesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundAllowRulesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an Inbound Allow rule.
.Description
Returns the properties of an Inbound Allow rule.
.Example
Get-ZNInboundAllowRule
.Example
Get-ZNInboundAllowRule -RuleId "be2bdc05-7837-4125-88ba-983e3ff7e763"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Link
https://github.com/zeronetworkszn.api/get-zninboundallowrule
#>
function Get-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded object {id: string, direction: AssetDirection}
    ${EntityParams},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNInboundAllowRule_Get';
            List = 'ZN.Api.private\Get-ZNInboundAllowRule_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destination candidates for Inbound Block rules.
.Description
Returns a list of destination candidates for Inbound Block rules.
.Example
(Get-ZNInboundBlockRulesDestinationCandidate).Items
.Example
(Get-ZNInboundBlockRulesDestinationCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrulesdestinationcandidate
#>
function Get-ZNInboundBlockRulesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundBlockRulesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of excluded destination candidates for Inbound Block rules.
.Description
Returns a list of excluded destination candidates for Inbound Block rules.
.Example
(Get-ZNInboundBlockRulesExcludedLocalCandidate).Items
.Example
(Get-ZNInboundBlockRulesExcludedLocalCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrulesexcludedlocalcandidate
#>
function Get-ZNInboundBlockRulesExcludedLocalCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundBlockRulesExcludedLocalCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates for Inbound Block rules.
.Description
Returns a list of source candidates for Inbound Block rules.
.Example
(Get-ZNInboundBlockRulesSourceCandidate).Items
.Example
(Get-ZNInboundBlockRulesSourceCandidate -Search "FS1").Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrulessourcecandidate
#>
function Get-ZNInboundBlockRulesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNInboundBlockRulesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the Inbound Block rule.
.Description
Returns the properties of the Inbound Block rule.
.Example
Get-ZNInboundBlockRule
.Example
Get-ZNInboundBlockRule -RuleId "9f3503cf-02ce-4231-b167-c9e2a2446311"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Link
https://github.com/zeronetworkszn.api/get-zninboundblockrule
#>
function Get-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded object {id: string, direction: AssetDirection}
    ${EntityParams},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNInboundBlockRule_Get';
            List = 'ZN.Api.private\Get-ZNInboundBlockRule_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties for JAMF Credentials Settings.
.Description
Returns the properties for JAMF Credentials Settings.
.Example
Get-ZNJamfCredentialsSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials
.Link
https://github.com/zeronetworkszn.api/get-znjamfcredentialssetting
#>
function Get-ZNJamfCredentialsSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNJamfCredentialsSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the linux user settings in Asset Managment
.Description
Get the linux user settings in Asset Managment
.Example
Get-ZNLinuxUserSetting

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znlinuxusersetting
#>
function Get-ZNLinuxUserSetting {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNLinuxUserSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of MFA authentication settings.
.Description
Returns the properties of MFA authentication settings.
.Example
Get-ZNMfaAuthenticationSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaAuthentication
.Link
https://github.com/zeronetworkszn.api/get-znmfaauthenticationsetting
#>
function Get-ZNMfaAuthenticationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaAuthentication], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMfaAuthenticationSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of MFA detection settings.
.Description
Returns the properties of MFA detection settings.
.Example
Get-ZNMfaDetectionSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection
.Link
https://github.com/zeronetworkszn.api/get-znmfadetectionsetting
#>
function Get-ZNMfaDetectionSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMfaDetectionSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of candidates for the destionation of an inbound MFA policy.
.Description
Returns a list of candidates for the destionation of an inbound MFA policy.
.Example
(Get-ZNMfaInboundPoliciesDestinationCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesDestinationCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciesdestinationcandidate
#>
function Get-ZNMfaInboundPoliciesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of MFA methods for inbound MFA policies.
.Description
Returns a list of MFA methods for inbound MFA policies.
.Example
Get-ZNMfaInboundPoliciesMfamethod

.Outputs
System.Int32
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciesmfamethod
#>
function Get-ZNMfaInboundPoliciesMfamethod {
[OutputType([System.Int32], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesMfamethod_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destination candidates on inbound MFA simulation.
.Description
Returns a list of destination candidates on inbound MFA simulation.
.Example
(Get-ZNMfaInboundPoliciesSimulateDestinationCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesSimulateDestinationCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciessimulatedestinationcandidate
#>
function Get-ZNMfaInboundPoliciesSimulateDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesSimulateDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates on inbound MFA simulation.
.Description
Returns a list of source candidates on inbound MFA simulation.
.Example
(Get-ZNMfaInboundPoliciesSimulateSourceCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesSimulateSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciessimulatesourcecandidate
#>
function Get-ZNMfaInboundPoliciesSimulateSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesSimulateSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source user candidates on inbound MFA simulation.
.Description
Returns a list of source user candidates on inbound MFA simulation.
.Example
(Get-ZNMfaInboundPoliciesSimulateSourceUserCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesSimulateSourceUserCandidate -Search Administrator).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciessimulatesourceusercandidate
#>
function Get-ZNMfaInboundPoliciesSimulateSourceUserCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesSimulateSourceUserCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates on inbound MFA policies.
.Description
Returns a list of source candidates on inbound MFA policies.
.Example
(Get-ZNMfaInboundPoliciesSourceCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciessourcecandidate
#>
function Get-ZNMfaInboundPoliciesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source user candidates for inbound MFA policies.
.Description
Returns a list of source user candidates for inbound MFA policies.
.Example
(Get-ZNMfaInboundPoliciesSourceUserCandidate).Items
.Example
(Get-ZNMfaInboundPoliciesSourceUserCandidate -Search administrator).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpoliciessourceusercandidate
#>
function Get-ZNMfaInboundPoliciesSourceUserCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaInboundPoliciesSourceUserCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a inbound MFA policy object.
.Description
Returns a inbound MFA policy object.
.Example
Get-ZNMfaInboundPolicy
.Example
Get-ZNMfaInboundPolicy -ReactivePolicyId "f68d322c-1cb0-451d-aff2-c920a1a17333"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Link
https://github.com/zeronetworkszn.api/get-znmfainboundpolicy
#>
function Get-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the MFA policy
    ${ReactivePolicyId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # entityId to filter on
    ${EntityId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMfaInboundPolicy_Get';
            List = 'ZN.Api.private\Get-ZNMfaInboundPolicy_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destination candidates on outbound MFA policies.
.Description
Returns a list of destination candidates on outbound MFA policies.
.Example
(Get-ZNMfaOutboundPoliciesDestinationCandidate).Items
.Example
(Get-ZNMfaOutboundPoliciesDestinationCandidate -Search webcam).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciesdestinationcandidate
#>
function Get-ZNMfaOutboundPoliciesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of MFA methods on outbound MFA policies.
.Description
Returns a list of MFA methods on outbound MFA policies.
.Example
Get-ZNMfaOutboundPoliciesMfamethod

.Outputs
System.Int32
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciesmfamethod
#>
function Get-ZNMfaOutboundPoliciesMfamethod {
[OutputType([System.Int32], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesMfamethod_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destination candidates on outbound MFA simulation.
.Description
Returns a list of destination candidates on outbound MFA simulation.
.Example
(Get-ZNMfaOutboundPoliciesSimulateDesinationCandidate).Items
.Example
(Get-ZNMfaOutboundPoliciesSimulateDesinationCandidate -Search webcam).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciessimulatedesinationcandidate
#>
function Get-ZNMfaOutboundPoliciesSimulateDesinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesSimulateDesinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates on outbound MFA simulation.
.Description
Returns a list of source candidates on outbound MFA simulation.
.Example
(Get-ZNMfaOutboundPoliciesSimulateSourceCandidate).Items 
.Example
(Get-ZNMfaOutboundPoliciesSimulateSourceCandidate -search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciessimulatesourcecandidate
#>
function Get-ZNMfaOutboundPoliciesSimulateSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesSimulateSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source users candidates on outbound MFA simulation.
.Description
Returns a list of source users candidates on outbound MFA simulation.
.Example
(Get-ZNMfaOutboundPoliciesSimulateSourceUserCandidate).Items 
.Example
(Get-ZNMfaOutboundPoliciesSimulateSourceUserCandidate -Search Administrator).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciessimulatesourceusercandidate
#>
function Get-ZNMfaOutboundPoliciesSimulateSourceUserCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesSimulateSourceUserCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates on outbound MFA policies.
.Description
Returns a list of source candidates on outbound MFA policies.
.Example
(Get-ZNMfaOutboundPoliciesSourceCandidate).Items
.Example
(Get-ZNMfaOutboundPoliciesSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciessourcecandidate
#>
function Get-ZNMfaOutboundPoliciesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source users candidates on outbound MFA policies.
.Description
Returns a list of source users candidates on outbound MFA policies.
.Example
(Get-ZNMfaOutboundPoliciesSourceUserCandidate).Items
.Example
(Get-ZNMfaOutboundPoliciesSourceUserCandidate -Search administrator).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpoliciessourceusercandidate
#>
function Get-ZNMfaOutboundPoliciesSourceUserCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISrcUserCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaOutboundPoliciesSourceUserCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an outbound MFA policy.
.Description
Returns the properties of an outbound MFA policy.
.Example
Get-ZNOutboundBlockRule
.Example
Get-ZNMfaOutboundPolicy -ReactivePolicyId "cff54715-454b-4309-9b70-3055d80a8379"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Link
https://github.com/zeronetworkszn.api/get-znmfaoutboundpolicy
#>
function Get-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the MFA policy
    ${ReactivePolicyId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMfaOutboundPolicy_Get';
            List = 'ZN.Api.private\Get-ZNMfaOutboundPolicy_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and object with MFA distrubiton.
.Description
Returns and object with MFA distrubiton.
.Example
Get-ZNMfaPoliciesDistribution

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyDistributionMfaDistributionItem
.Link
https://github.com/zeronetworkszn.api/get-znmfapoliciesdistribution
#>
function Get-ZNMfaPoliciesDistribution {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyDistributionMfaDistributionItem], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaPoliciesDistribution_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with MFA statistics.
.Description
Returns an object with MFA statistics.
.Example
Get-ZNMfaPoliciesStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePoliciesStatisticsReactivePoliciesStatistics
.Link
https://github.com/zeronetworkszn.api/get-znmfapoliciesstatistics
#>
function Get-ZNMfaPoliciesStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePoliciesStatisticsReactivePoliciesStatistics], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNMfaPoliciesStatistics_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the monitored group candidates
.Description
Get the monitored group candidates
.Example
(Get-ZNMonitoredGroupCandidatesSetting).Items
.Example
(Get-ZNMonitoredGroupCandidatesSetting -Search "All AD Assets").Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znmonitoredgroupcandidatessetting
#>
function Get-ZNMonitoredGroupCandidatesSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMonitoredGroupCandidatesSetting_Get';
        }
        if (('Get') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the monitored group settings in Asset Managment
.Description
Get the monitored group settings in Asset Managment
.Example
Get-ZNMonitoredGroupSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup
.Link
https://github.com/zeronetworkszn.api/get-znmonitoredgroupsetting
#>
function Get-ZNMonitoredGroupSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNMonitoredGroupSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the Mail Notification settings.
.Description
Returns the properties of the Mail Notification settings.
.Example
Get-ZNNotificationSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification
.Link
https://github.com/zeronetworkszn.api/get-znnotificationsetting
#>
function Get-ZNNotificationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNNotificationSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destination candidates for Outbound Allow rules.
.Description
Returns a list of destination candidates for Outbound Allow rules.
.Example
(Get-ZNOutboundAllowRulesDestinationCandidate).Items
.Example
(Get-ZNOutboundAllowRulesDestinationCandidate -search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrulesdestinationcandidate
#>
function Get-ZNOutboundAllowRulesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundAllowRulesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of excluded source candidates for Outbound Allow rules.
.Description
Returns a list of excluded source candidates for Outbound Allow rules.
.Example
(Get-ZNOutboundAllowRulesExcludedSourceCandidate).Items
.Example
(Get-ZNOutboundAllowRulesExcludedSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrulesexcludedsourcecandidate
#>
function Get-ZNOutboundAllowRulesExcludedSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundAllowRulesExcludedSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates for Outbound Allow rules.
.Description
Returns a list of source candidates for Outbound Allow rules.
.Example
(Get-ZNOutboundAllowRulesSourceCandidate).Items
.Example
(Get-ZNOutboundAllowRulesSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrulessourcecandidate
#>
function Get-ZNOutboundAllowRulesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundAllowRulesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an Outbound Allow rule.
.Description
Returns the properties of an Outbound Allow rule.
.Example
Get-ZNOutboundAllowRule
.Example
 Get-ZNOutboundAllowRule -RuleId "c551b646-75d1-477d-8023-367461883fd7"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Link
https://github.com/zeronetworkszn.api/get-znoutboundallowrule
#>
function Get-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded object {id: string, direction: AssetDirection}
    ${EntityParams},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNOutboundAllowRule_Get';
            List = 'ZN.Api.private\Get-ZNOutboundAllowRule_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of destioantion candidates for outbound block rules.
.Description
Returns a list of destioantion candidates for outbound block rules.
.Example
(Get-ZNOutboundBlockRulesDestinationCandidate).Items
.Example
(Get-ZNOutboundBlockRulesDestinationCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrulesdestinationcandidate
#>
function Get-ZNOutboundBlockRulesDestinationCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundBlockRulesDestinationCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of excluded source candidates for outbound block rules.
.Description
Returns a list of excluded source candidates for outbound block rules.
.Example
(Get-ZNOutboundBlockRulesExcludedSourceCandidate).Items
.Example
(Get-ZNOutboundBlockRulesExcludedSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrulesexcludedsourcecandidate
#>
function Get-ZNOutboundBlockRulesExcludedSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundBlockRulesExcludedSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of source candidates for outbound block rules.
.Description
Returns a list of source candidates for outbound block rules.
.Example
(Get-ZNOutboundBlockRulesSourceCandidate).Items
.Example
(Get-ZNOutboundBlockRulesSourceCandidate -Search DC1).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrulessourcecandidate
#>
function Get-ZNOutboundBlockRulesSourceCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNOutboundBlockRulesSourceCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an outbound block rule.
.Description
Returns the properties of an outbound block rule.
.Example
Get-ZNOutboundBlockRule
.Example
Get-ZNOutboundBlockRule -RuleId "0faafa72-2540-4d55-9418-ed62472e0e2d"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Link
https://github.com/zeronetworkszn.api/get-znoutboundblockrule
#>
function Get-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded object {id: string, direction: AssetDirection}
    ${EntityParams},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNOutboundBlockRule_Get';
            List = 'ZN.Api.private\Get-ZNOutboundBlockRule_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis

.Description

.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProfileResponse
.Link
https://github.com/zeronetworkszn.api/get-znprofile
#>
function Get-ZNProfile {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProfileResponse], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNProfile_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of candidates for Protection Automation settings.
.Description
Returns a list of candidates for Protection Automation settings.
.Example
(Get-ZNProtectionAutomationCandidatesSetting).Items
.Example
(Get-ZNProtectionAutomationCandidatesSetting -Search "ZeroNetworksProtectedAssets").Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znprotectionautomationcandidatessetting
#>
function Get-ZNProtectionAutomationCandidatesSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNProtectionAutomationCandidatesSetting_Get';
        }
        if (('Get') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of Protection Automation settings.
.Description
Returns the properties of Protection Automation settings.
.Example
Get-ZNProtectionAutomationSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidate
.Link
https://github.com/zeronetworkszn.api/get-znprotectionautomationsetting
#>
function Get-ZNProtectionAutomationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidate], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNProtectionAutomationSetting_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of candidates for protection policies.
.Description
Returns a list of candidates for protection policies.
.Example
(Get-ZNProtectionPoliciesGroupCandidate).Items
.Example
(Get-ZNProtectionPoliciesGroupCandidate -Search Clients).Items

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList
.Link
https://github.com/zeronetworkszn.api/get-znprotectionpoliciesgroupcandidate
#>
function Get-ZNProtectionPoliciesGroupCandidate {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroupCandidatesList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNProtectionPoliciesGroupCandidate_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of protection policies.
.Description
Returns a list of protection policies.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy
.Link
https://github.com/zeronetworkszn.api/get-znprotectionpolicy
#>
function Get-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNProtectionPolicy_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with rules distribution.
.Description
Returns an object with rules distribution.
.Example
Get-ZNRulesDistribution -RuleId 2f9fd777-d735-4cac-99c5-5f822318e510 -RuleDirection 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDistribution
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znrulesdistribution
#>
function Get-ZNRulesDistribution {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDistribution], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # direction of the rule (1-Inbound, 2-Outbound)
    ${RuleDirection},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNRulesDistribution_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an object with rule statistics.
.Description
Returns an object with rule statistics.
.Example
 Get-ZNRulesStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleStatistics
.Link
https://github.com/zeronetworkszn.api/get-znrulesstatistics
#>
function Get-ZNRulesStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRuleStatistics], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNRulesStatistics_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the portal security settings
.Description
Get the portal security settings
.Example
Get-ZNSettingsAuth

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAuthBodyItem
.Link
https://github.com/zeronetworkszn.api/get-znsettingsauth
#>
function Get-ZNSettingsAuth {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAuthBodyItem], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNSettingsAuth_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of System groups.
.Description
Returns a list of System groups.
.Example
Get-ZNSystemGroup
.Example
 Get-ZNSystemGroup -Offset 10

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-znsystemgroup
#>
function Get-ZNSystemGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNSystemGroup_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of Tags.
.Description
Returns a list of Tags.
.Example
Get-ZNTagGroup
.Example
 Get-ZNTagGroup -Offset 10

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-zntaggroup
#>
function Get-ZNTagGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNTagGroup_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of trust servers.
.Description
Returns a list of trust servers.
.Example
Get-ZNTrustServer

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDeployment
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-zntrustserver
#>
function Get-ZNTrustServer {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IDeployment], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            List = 'ZN.Api.private\Get-ZNTrustServer_List';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of audits for the user.
.Description
Returns a list of audits for the user.
.Example
Get-ZNUserAudit -UserId u:a:E6iXCia4

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/get-znuseraudit
#>
function Get-ZNUserAudit {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAuditList], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # userId to filter on
    ${UserId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int64]
    # cursor position to start at
    ${Cursor},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # What order to sort the results
    ${Order},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNUserAudit_Get';
        }
        if (('Get') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a list of groups the user is a member of.
.Description
Returns a list of groups the user is a member of.
.Example
Get-ZNUserMemberOf -UserId u:a:E6iXCia4

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/get-znusermemberof
#>
function Get-ZNUserMemberOf {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # userId to filter on
    ${UserId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNUserMemberOf_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get Users statistics
.Description
Get Users statistics
.Example
Get-ZNUserStatistics

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUserStatisticsAutoGenerated
.Link
https://github.com/zeronetworkszn.api/get-znuserstatistics
#>
function Get-ZNUserStatistics {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUserStatisticsAutoGenerated], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Get', PositionalBinding=$false)]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNUserStatistics_Get';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of an user.
.Description
Returns the properties of an user.
.Example
Get-ZNUser
.Example
 Get-ZNUser -Offset 10
.Example
Get-ZNUser -Search Administrator

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUser
.Link
https://github.com/zeronetworkszn.api/get-znuser
#>
function Get-ZNUser {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IUser], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='List', PositionalBinding=$false)]
param(
    [Parameter(ParameterSetName='Get', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # userId to filter on
    ${UserId},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='Limit Default', Description='Sets the limit parameter to 10', Script='10')]
    [System.Int32]
    # Limit the return results
    ${Limit},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # JSON string URI encoded set of fiters
    ${Filters},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.Int32]
    # Used to page through results
    ${Offset},

    [Parameter(ParameterSetName='List')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # Test to search for
    ${Search},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Get = 'ZN.Api.private\Get-ZNUser_Get';
            List = 'ZN.Api.private\Get-ZNUser_List';
        }
        if (('List') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('Limit')) {
            $PSBoundParameters['Limit'] = 10
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the assetId after encoding the IP range.
.Description
Returns the assetId after encoding the IP range.
.Example
Invoke-ZNEncodeEntityIPRange -IPRange 1.1.1.1-1.1.1.2 

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/invoke-znencodeentityiprange
#>
function Invoke-ZNEncodeEntityIPRange {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Encode', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # IP Address Range
    ${IPRange},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Encode = 'ZN.Api.private\Invoke-ZNEncodeEntityIPRange_Encode';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the assetId after encoding the IP address.
.Description
Returns the assetId after encoding the IP address.
.Example
Invoke-ZNEncodeEntityIP -IP 1.1.1.1

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/invoke-znencodeentityip
#>
function Invoke-ZNEncodeEntityIP {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Encode', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # IP address
    ${IP},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Encode = 'ZN.Api.private\Invoke-ZNEncodeEntityIP_Encode';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the assetId after encoding the IP subnet.
.Description
Returns the assetId after encoding the IP subnet.
.Example
Invoke-ZNEncodeEntitySubnet -Subnet 1.1.1.0/24 

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/invoke-znencodeentitysubnet
#>
function Invoke-ZNEncodeEntitySubnet {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Encode', PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # IP Subnet
    ${Subnet},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Encode = 'ZN.Api.private\Invoke-ZNEncodeEntitySubnet_Encode';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Invoke-ZNExtendAssetQueue -Items @((Search-ZNAsset -Fqdn fs1.zero.labs)) -ExtendByDays 14

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IQueueExtendBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IQueueExtendBody>: .
  [ExtendByDays <Int32?>]: number of days
  [Items <String[]>]: 
.Link
https://github.com/zeronetworkszn.api/invoke-znextendassetqueue
#>
function Invoke-ZNExtendAssetQueue {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='ExtendExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Extend', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IQueueExtendBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='ExtendExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # number of days
    ${ExtendByDays},

    [Parameter(ParameterSetName='ExtendExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Extend = 'ZN.Api.private\Invoke-ZNExtendAssetQueue_Extend';
            ExtendExpanded = 'ZN.Api.private\Invoke-ZNExtendAssetQueue_ExtendExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and empty object.
.Description
Returns and empty object.
.Example
Invoke-ZNQueueAsset -Items @((Search-ZNAsset -Fqdn fs1.zero.labs)) -QueueDays 14

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IQueueBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IQueueBody>: .
  [Items <String[]>]: 
  [QueueDays <Int32?>]: number of days
.Link
https://github.com/zeronetworkszn.api/invoke-znqueueasset
#>
function Invoke-ZNQueueAsset {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='QueueExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Queue', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IQueueBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='QueueExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(ParameterSetName='QueueExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # number of days
    ${QueueDays},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Queue = 'ZN.Api.private\Invoke-ZNQueueAsset_Queue';
            QueueExpanded = 'ZN.Api.private\Invoke-ZNQueueAsset_QueueExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Rediscover monitored assets from Ansible
.Description
Rediscover monitored assets from Ansible
.Example
Invoke-ZNRediscoverAnsibleSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/invoke-znrediscoveransiblesetting
#>
function Invoke-ZNRediscoverAnsibleSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Rediscover', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Rediscover = 'ZN.Api.private\Invoke-ZNRediscoverAnsibleSetting_Rediscover';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Rediscover monitored assets
.Description
Rediscover monitored assets
.Example
Invoke-ZNRediscoverMonitoredGroupSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/invoke-znrediscovermonitoredgroupsetting
#>
function Invoke-ZNRediscoverMonitoredGroupSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Rediscover', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Rediscover = 'ZN.Api.private\Invoke-ZNRediscoverMonitoredGroupSetting_Rediscover';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Add a secondary AD settings in Asset Managment
.Description
Add a secondary AD settings in Asset Managment
.Example
New-ZNAdSecondarySetting -DomainId newdomain.zero.labs -Dc dc1.newdomain.zero.labs

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/new-znadsecondarysetting
#>
function New-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The fqdn of the domain
    ${DomainId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The domain controller
    ${Dc},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNAdSecondarySetting_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the assetId of the created Linux asset.
.Description
Returns the assetId of the created Linux asset.
.Example
New-ZNAssetsLinux -DisplayName "linuxservera" -Fqdn "linuxservera.zero.labs"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetId
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/new-znassetslinux
#>
function New-ZNAssetsLinux {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetId], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DisplayName},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Fqdn},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNAssetsLinux_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
New-ZNAssetsOt -DisplayName webcam2 -Ipv4 "192.168.10.30" -Type 4 

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/new-znassetsot
#>
function New-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DisplayName},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Ipv4},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Single]
    # .
    ${Type},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNAssetsOt_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
New-ZNCustomGroup -Name "test3" -Description "test custom group"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/new-zncustomgroup
#>
function New-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Name},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # members id
    ${MembersId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNCustomGroup_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Create an identity provider settings in Identity Providers
.Description
Create an identity provider settings in Identity Providers
.Example
New-ZNIdpSetting  -IdentityProvider "azure" -SloUrl "https://login.microsoftonline.com/d6eebbdd-d77c-465e-b008-4339027b4006/saml2" -SsoUrl "https://login.microsoftonline.com/d6eebbdd-d77c-465e-b008-4339027b4006/saml2" -IsDefault:$false -Certificate 'MIIC...'

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp
.Link
https://github.com/zeronetworkszn.api/new-znidpsetting
#>
function New-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Identity Provider certificate
    ${Certificate},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${IdentityProvider},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Set as the default authentication method
    ${IsDefault},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single Log out url
    ${SloUrl},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single sign on url
    ${SsoUrl},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNIdpSetting_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Inbound Allow rule.
.Description
Returns the properties of the created Inbound Allow rule.
.Example
$portsList = New-ZNPortsList -Protocol TCP -Ports "44,45"
$source = (Get-ZNInboundAllowRulesSourceCandidate -search "any asset").Items
$destination = (Get-ZNInboundAllowRulesDestinationCandidate -Search FS1).Items
New-ZNInboundAllowRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/new-zninboundallowrule
#>
function New-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNInboundAllowRule_CreateExpanded';
        }
        if (('CreateExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Inbound Block rule.
.Description
Returns the properties of the created Inbound Block rule.
.Example
$portsList = New-ZNPortsList -Protocol Any
$source = (Get-ZNInboundBlockRulesSourceCandidate -Search "win7").Items
$destination = (Get-ZNInboundBlockRulesDestinationCandidate -Search "all protected Assets").Items
New-ZNInboundBlockRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/new-zninboundblockrule
#>
function New-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNInboundBlockRule_CreateExpanded';
        }
        if (('CreateExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the inbound MFA policy after creation.
.Description
Returns the properties of the inbound MFA policy after creation.
.Example
$destination = (Get-ZNMfaInboundPoliciesDestinationCandidate -Search "linuxserver").Items
$source = (Get-ZNMfaInboundPoliciesSourceCandidate -search "Any Asset").Items
$sourceEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcEntityInfosItem]::new()
$sourceEntity.Id = $source.Id
$sourceUser = (Get-ZNMfaInboundPoliciesSourceUserCandidate -search "Any User").Items
$sourceUserEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcUserInfosItem]::new()
$sourceUserEntity.Id = $sourceUser.Id
New-ZNMfaInboundPolicy -DstEntityInfoId $destination.Id -DstPort "22" -DstProcessNames @("*") -FallbackToLoggedOnUser -MfaMethods @(4) -ProtocolType 6 -RuleDuration 6 -SrcEntityInfos @($sourceEntity) -SrcProcessNames @("*") -SrcUserInfos @($sourceUserEntity) -RuleCreationMode 1 -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

SRCENTITYINFOS <IReactivePolicyInboundBodySrcEntityInfosItem[]>: .
  Id <String>: 

SRCUSERINFOS <IReactivePolicyInboundBodySrcUserInfosItem[]>: .
  Id <String>: 
.Link
https://github.com/zeronetworkszn.api/new-znmfainboundpolicy
#>
function New-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstEntityInfoId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstPort},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${DstProcessNames},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${FallbackToLoggedOnUser},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # .
    ${MfaMethods},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${ProtocolType},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${RuleDuration},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBodySrcEntityInfosItem[]]
    # .
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${SrcProcessNames},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyInboundBodySrcUserInfosItem[]]
    # .
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNMfaInboundPolicy_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a the properties of outbound MFA policy created.
.Description
Returns a the properties of outbound MFA policy created.
.Example
$destination = (Get-ZNMfaOutboundPoliciesDestinationCandidate -Search "switch01").Items
$source = (Get-ZNMfaOutboundPoliciesSourceCandidate -search "All Protected Assets").Items
$sourceEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcEntityInfosItem]::new()
$sourceEntity.Id = $source.Id
$sourceUser = (Get-ZNMfaInboundPoliciesSourceUserCandidate -search "Any User").Items
$sourceUserEntity = [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcUserInfosItem]::new()
$sourceUserEntity.Id = $sourceUser.Id
New-ZNMfaOutboundPolicy -DstEntityInfoId $destination.Id -DstPort "22" -FallbackToLoggedOnUser -MfaMethods @(4) -ProtocolType 6 -RuleDuration 6 -SrcEntityInfos @($sourceEntity) -SrcProcessNames @("*") -SrcUserInfos @($sourceUserEntity) -RuleCreationMode 1 -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

SRCENTITYINFOS <IReactivePolicyOutboundBodySrcEntityInfosItem[]>: .
  Id <String>: 

SRCUSERINFOS <IReactivePolicyOutboundBodySrcUserInfosItem[]>: .
  Id <String>: 
.Link
https://github.com/zeronetworkszn.api/new-znmfaoutboundpolicy
#>
function New-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstEntityInfoId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DstPort},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${DstProcessNames},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${FallbackToLoggedOnUser},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # .
    ${MfaMethods},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${ProtocolType},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${RuleDuration},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBodySrcEntityInfosItem[]]
    # .
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${SrcProcessNames},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IReactivePolicyOutboundBodySrcUserInfosItem[]]
    # .
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNMfaOutboundPolicy_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created Outbound Allow rule.
.Description
Returns the properties of the created Outbound Allow rule.
.Example
$portsList = New-ZNPortsList -Protocol TCP -Ports "53"
$source = (Get-ZNOutboundAllowRulesSourceCandidate -search "all protected assets").Items
$destination = Invoke-ZNEncodeEntityIp -IP 8.8.8.8
New-ZNOutboundAllowRule -LocalEntityId $destination.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($source.id) -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/new-znoutboundallowrule
#>
function New-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNOutboundAllowRule_CreateExpanded';
        }
        if (('CreateExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the created outbound block rule.
.Description
Returns the properties of the created outbound block rule.
.Example
$portsList = New-ZNPortsList -Protocol Any
$source = (Get-ZNOutboundAllowRulesSourceCandidate -search "all protected assets").Items
$destination = Invoke-ZNEncodeEntityIp -IP 1.2.3.4 #MalicousIP
New-ZNOutboundBlockRule -LocalEntityId $source.Id -LocalProcessesList @("*") -PortsList $portsList -RemoteEntityIdsList @($destination) -State 1

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <IPortsListItem[]>: .
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworkszn.api/new-znoutboundblockrule
#>
function New-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IRule], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${LocalEntityId},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${LocalProcessesList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IPortsListItem[]]
    # .
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${RemoteEntityIdsList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1=Enabled, 2=Disabled
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.DefaultInfo(Name='ExpiresAt Default', Description='Sets the expiresAt parmaeter to 0 or never.', Script='0')]
    [System.Int32]
    # .
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ExcludedLocalIdsList},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNOutboundBlockRule_CreateExpanded';
        }
        if (('CreateExpanded') -contains $parameterSet -and -not $PSBoundParameters.ContainsKey('ExpiresAt')) {
            $PSBoundParameters['ExpiresAt'] = 0
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the protection policy that was created.
.Description
Returns the protection policy that was created.
.Example
# There are multiple groups with Domain Controllers in the name
$group = Get-ZNADGroup -Search "Domain Controllers" | where {$_.Name -eq "Domain Controllers"}
New-ZNProtectionPolicy -GroupId $group.Id -MinQueueDays 30 -InitialQueueDays 30

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy
.Link
https://github.com/zeronetworkszn.api/new-znprotectionpolicy
#>
function New-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='CreateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${GroupId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${InitialQueueDays},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${MinQueueDays},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${Description},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            CreateExpanded = 'ZN.Api.private\New-ZNProtectionPolicy_CreateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty response.
.Description
Returns an empty response.
.Example
Protect-ZNAssetsOt -Items "a:t:oOkjcyED"
.Example
Protect-ZNAssetsOT -Items ((Get-ZNAssetsOt).Id)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/protect-znassetsot
#>
function Protect-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='ProtectExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Protect', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='ProtectExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Protect = 'ZN.Api.private\Protect-ZNAssetsOt_Protect';
            ProtectExpanded = 'ZN.Api.private\Protect-ZNAssetsOt_ProtectExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and empty object.
.Description
Returns and empty object.
.Example
Protect-ZNAsset -Items "a:a:ZgBWOMyc"
.Example
Protect-ZNAsset -Items ((Get-ZNAssetsQueued).Items.Id)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/protect-znasset
#>
function Protect-ZNAsset {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='ProtectExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Protect', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='ProtectExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Protect = 'ZN.Api.private\Protect-ZNAsset_Protect';
            ProtectExpanded = 'ZN.Api.private\Protect-ZNAsset_ProtectExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty reponse.
.Description
Returns an empty reponse.
.Example
Remove-ZNAdSecondarySetting -DomainId newdomain.zero.labs

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znadsecondarysetting
#>
function Remove-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The fqdn of the domain
    ${DomainId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNAdSecondarySetting_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Remove-ZNCustomGroupsMember -GroupId "g:c:gP9POclU" -MembersId "a:a:GnyWAsYs"

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity
.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <ICustomGroupMembersBody>: .
  MembersId <String[]>: members id

INPUTOBJECT <IApiIdentity>: Identity Parameter
  [AssetId <String>]: assetId to filter on
  [ClientId <String>]: clientId to filter on
  [DomainId <String>]: The fqdn of the domain
  [ExportId <String>]: exportId to download
  [GroupId <String>]: groupId to filter on
  [IdentityProviderId <String>]: Identity provider Id
  [ProtectionPolicyId <String>]: The id of the protection policy
  [ReactivePolicyId <String>]: The id of the MFA policy
  [RoleEntityId <String>]: The id of the user
  [RuleId <String>]: The id of the rule
  [UserId <String>]: userId to filter on
.Link
https://github.com/zeronetworkszn.api/remove-zncustomgroupsmember
#>
function Remove-ZNCustomGroupsMember {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='DeleteExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Delete', Mandatory)]
    [Parameter(ParameterSetName='DeleteExpanded', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(ParameterSetName='DeleteViaIdentityExpanded', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IApiIdentity]
    # Identity Parameter
    # To construct, see NOTES section for INPUTOBJECT properties and create a hash table.
    ${InputObject},

    [Parameter(ParameterSetName='Delete', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ICustomGroupMembersBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='DeleteExpanded', Mandatory)]
    [Parameter(ParameterSetName='DeleteViaIdentityExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # members id
    ${MembersId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNCustomGroupsMember_Delete';
            DeleteExpanded = 'ZN.Api.private\Remove-ZNCustomGroupsMember_DeleteExpanded';
            DeleteViaIdentityExpanded = 'ZN.Api.private\Remove-ZNCustomGroupsMember_DeleteViaIdentityExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Remove-ZNCustomGroup -GroupId "g:c:h8I6V0TB"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-zncustomgroup
#>
function Remove-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNCustomGroup_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty reponse.
.Description
Returns an empty reponse.
.Example
Remove-ZNIdpSetting -IdentityProviderId azure

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znidpsetting
#>
function Remove-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # Identity provider Id
    ${IdentityProviderId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNIdpSetting_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNInboundAllowRule | where {$_.Description -eq "Test Rule A"}
Remove-ZNInboundAllowRule -RuleId $rule.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-zninboundallowrule
#>
function Remove-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNInboundAllowRule_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNInboundBlockRule | where {$_.Description -eq "Test Rule"}
Remove-ZNInboundBlockRule -RuleId $rule.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-zninboundblockrule
#>
function Remove-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNInboundBlockRule_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Remove-ZNJamfCredentialsSetting

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znjamfcredentialssetting
#>
function Remove-ZNJamfCredentialsSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNJamfCredentialsSetting_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$policy = Get-ZNMfaInboundPolicy | where {$_.Description -eq "Test Policy"}
Remove-ZNMfaInboundPolicy -ReactivePolicyId $policy.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znmfainboundpolicy
#>
function Remove-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the MFA policy
    ${ReactivePolicyId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNMfaInboundPolicy_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$policy = Get-ZNMfaOutboundPolicy | where {$_.Description -eq "Test Policy"}
Remove-ZNMfaOutboundPolicy -ReactivePolicyId $policy.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znmfaoutboundpolicy
#>
function Remove-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${ReactivePolicyId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNMfaOutboundPolicy_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNOutboundAllowRule | where {$_.Description -eq "Test Rule"}
Remove-ZNOutboundAllowRule -RuleId $rule.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znoutboundallowrule
#>
function Remove-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNOutboundAllowRule_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$rule = Get-ZNOutboundBlockRule | where {$_.Description -eq "Test Rule"}
Remove-ZNOutboundBlockRule -RuleId $rule.Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znoutboundblockrule
#>
function Remove-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the rule
    ${RuleId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNOutboundBlockRule_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and empty object.
.Description
Returns and empty object.
.Example
Remove-ZNProtectionPolicy -ProtectionPolicyId "25b60e5f-3201-48b0-8f04-3df5eb4e2948"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/remove-znprotectionpolicy
#>
function Remove-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Delete', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the protection policy
    ${ProtectionPolicyId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Delete = 'ZN.Api.private\Remove-ZNProtectionPolicy_Delete';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an assetId.
.Description
Returns an assetId.
.Example
Search-ZNAsset -Fqdn dc1.zero.labs

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/search-znasset
#>
function Search-ZNAsset {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Search', PositionalBinding=$false)]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Query')]
    [System.String]
    # fully qualifed domain name
    ${Fqdn},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Search = 'ZN.Api.private\Search-ZNAsset_Search';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a number of assets that are valid for protection.
.Description
Returns a number of assets that are valid for protection.
.Example
Test-ZNAssetsProtection -Items (Search-ZNAsset -Fqdn WIN7.zero.labs)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
System.Int32
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/test-znassetsprotection
#>
function Test-ZNAssetsProtection {
[OutputType([System.Int32], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='ValidateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Validate', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='ValidateExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Validate = 'ZN.Api.private\Test-ZNAssetsProtection_Validate';
            ValidateExpanded = 'ZN.Api.private\Test-ZNAssetsProtection_ValidateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns a number of assets that are valid to unprotect.
.Description
Returns a number of assets that are valid to unprotect.
.Example
Test-ZNAssetsUnprotect -Items (Search-ZNAsset -Fqdn WIN7.zero.labs)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
System.Int32
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/test-znassetsunprotect
#>
function Test-ZNAssetsUnprotect {
[OutputType([System.Int32], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='ValidateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Validate', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='ValidateExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Validate = 'ZN.Api.private\Test-ZNAssetsUnprotect_Validate';
            ValidateExpanded = 'ZN.Api.private\Test-ZNAssetsUnprotect_ValidateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns and empty body.
.Description
Returns and empty body.
.Example
Unprotect-ZNAssetsOt -Items (Search-ZNAsset -Fqdn switch01)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/unprotect-znassetsot
#>
function Unprotect-ZNAssetsOt {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UnprotectExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Unprotect', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UnprotectExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Unprotect = 'ZN.Api.private\Unprotect-ZNAssetsOt_Unprotect';
            UnprotectExpanded = 'ZN.Api.private\Unprotect-ZNAssetsOt_UnprotectExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
Unprotect-ZNAsset -Items (Search-ZNAsset -Fqdn dc1.zero.labs)

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAssetBody>: .
  Items <String[]>: 
.Link
https://github.com/zeronetworkszn.api/unprotect-znasset
#>
function Unprotect-ZNAsset {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UnprotectExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Unprotect', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAssetBody]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='UnprotectExpanded', Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${Items},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Unprotect = 'ZN.Api.private\Unprotect-ZNAsset_Unprotect';
            UnprotectExpanded = 'ZN.Api.private\Unprotect-ZNAsset_UnprotectExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the Activities settings in Data Collection
.Description
Update the Activities settings in Data Collection
.Example
Update-ZNActivitiesSetting -ShouldFilterExternalTraffic:$false

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znactivitiessetting
#>
function Update-ZNActivitiesSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # Collection of IP subnets that are internal
    ${PrivateNetworksList},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Disable/Enable external traffic collection
    ${ShouldFilterExternalTraffic},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNActivitiesSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update a secondary AD settings in Asset Managment
.Description
Update a secondary AD settings in Asset Managment
.Example
Update-ZNAdSecondarySetting -dc dc2.newdomain.zero.labs -DomainId newdomain.zero.labs

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znadsecondarysetting
#>
function Update-ZNAdSecondarySetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The fqdn of the domain
    ${DomainId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The domain controller
    ${Dc},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNAdSecondarySetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set the AD settings in Asset Managment
.Description
Set the AD settings in Asset Managment
.Example
Update-ZNAdSetting -Domain zero.labs -DomainControllerFqdn dc1.zero.labs -Username znremotemanagement -Password "password" -UseLdaps:$false

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo
.Link
https://github.com/zeronetworkszn.api/update-znadsetting
#>
function Update-ZNAdSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAdInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='PutExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # FQDN of the AD domain
    ${Domain},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Domain Controller from AD Domain
    ${DomainControllerFqdn},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Service Acount Password
    ${Password},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Use LDAP or LDAPs
    ${UseLdaps},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Service Account for Zero Networks
    ${Username},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            PutExpanded = 'ZN.Api.private\Update-ZNAdSetting_PutExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set AI network exclusion for clients and servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Set AI network exclusion for clients and servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Update-ZNAiExclusionNetworkBoth -Icmp -ProcessesList @()  -TcpPorts "" -UdpPorts ""
.Example
$aiSettings = Get-ZNAiExclusionNetworkBoth
Update-ZNAiExclusionNetworkBoth -Icmp:$aiSettings.Icmp -ProcessesList $aiSettings.ProcessesList  -TcpPorts ($aiSettings.TcpPorts += "443") -UdpPorts $aiSettings.UdpPorts

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAiExclusionInfo>: .
  [Icmp <Boolean?>]: 
  [ProcessesList <String[]>]: 
  [TcpPorts <String>]: 
  [UdpPorts <String>]: 
.Link
https://github.com/zeronetworkszn.api/update-znaiexclusionnetworkboth
#>
function Update-ZNAiExclusionNetworkBoth {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='SetExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Set', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${Icmp},

    [Parameter(ParameterSetName='SetExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ProcessesList},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${TcpPorts},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${UdpPorts},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Set = 'ZN.Api.private\Update-ZNAiExclusionNetworkBoth_Set';
            SetExpanded = 'ZN.Api.private\Update-ZNAiExclusionNetworkBoth_SetExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set AI network exclusion for clients: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Set AI network exclusion for clients: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Update-ZNAiExclusionNetworkClient -Icmp -ProcessesList @()  -TcpPorts "" -UdpPorts ""
.Example
$aiSettings = Get-ZNAiExclusionNetworkClient
Update-ZNAiExclusionNetworkClient -Icmp:$aiSettings.Icmp -ProcessesList $aiSettings.ProcessesList  -TcpPorts ($aiSettings.TcpPorts += "443") -UdpPorts $aiSettings.UdpPorts

.Inputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

BODY <IAiExclusionInfo>: .
  [Icmp <Boolean?>]: 
  [ProcessesList <String[]>]: 
  [TcpPorts <String>]: 
  [UdpPorts <String>]: 
.Link
https://github.com/zeronetworkszn.api/update-znaiexclusionnetworkclient
#>
function Update-ZNAiExclusionNetworkClient {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='SetExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Set', Mandatory, ValueFromPipeline)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo]
    # .
    # To construct, see NOTES section for BODY properties and create a hash table.
    ${Body},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${Icmp},

    [Parameter(ParameterSetName='SetExpanded')]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ProcessesList},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${TcpPorts},

    [Parameter(ParameterSetName='SetExpanded')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${UdpPorts},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Set = 'ZN.Api.private\Update-ZNAiExclusionNetworkClient_Set';
            SetExpanded = 'ZN.Api.private\Update-ZNAiExclusionNetworkClient_SetExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Description
Set AI network exclusion for servers: lists of tcp/udp ports / ports ranges + boolean for icmp protocol, and a list of processes to ignore during learning.
.Example
Update-ZNAiExclusionNetworkServer -Icmp -ProcessesList @()  -TcpPorts "" -UdpPorts ""
.Example
$aiSettings = Get-ZNAiExclusionNetworkServer
Update-ZNAiExclusionNetworkServer -Icmp:$aiSettings.Icmp -ProcessesList $aiSettings.ProcessesList  -TcpPorts ($aiSettings.TcpPorts += "443") -UdpPorts $aiSettings.UdpPorts

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znaiexclusionnetworkserver
#>
function Update-ZNAiExclusionNetworkServer {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAiExclusionInfo], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='PutExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${Icmp},

    [Parameter()]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # .
    ${ProcessesList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${TcpPorts},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${UdpPorts},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            PutExpanded = 'ZN.Api.private\Update-ZNAiExclusionNetworkServer_PutExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set AI source entities to ignore during learning.
.Description
Set AI source entities to ignore during learning.
.Example
Update-ZNAiExclusionSrcEntity -Body (Search-ZNAsset -Fqdn dc1.zero.labs)
.Example
$excludedSources = @()
$excludedSources += (Get-ZNAiExclusionSrcEntity).Id
Update-ZNAiExclusionSrcEntity -Body ($excludedSources += (Search-ZNAsset -Fqdn fs1.zero.labs))

.Inputs
System.String[]
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znaiexclusionsrcentity
#>
function Update-ZNAiExclusionSrcEntity {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='Set', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory, ValueFromPipeline)]
    [AllowEmptyCollection()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # Array of PutContentSchemaItem
    ${Body},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Set = 'ZN.Api.private\Update-ZNAiExclusionSrcEntity_Set';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Get the Ansible settings in Asset Managment
.Description
Get the Ansible settings in Asset Managment
.Example
Update-ZNAnsibleSetting -ClientId "clientId" -CredentialsName ssh -DisableCertificateValidation:$false -Password "password" -Url "https:1.2.3.4" -Username "ZNAccess"
.Example
$ansible = Get-ZNAnsibleSetting
Update-ZNAnsibleSetting -ClientId $ansible.ClientId -CredentialsName $ansible.CredentialsName -DisableCertificateValidation:$ansible.DisableCertificateValidation -Password "newpassword" -Url $ansible.Url -Username $ansible.Username -ClientSecret "clientSecret"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible
.Link
https://github.com/zeronetworkszn.api/update-znansiblesetting
#>
function Update-ZNAnsibleSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsAnsible], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # OAuth Client Id
    ${ClientId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # OAuth Client Secret
    ${ClientSecret},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Name of the creds used to instruct Ansible to connect to linux machines
    ${CredentialsName},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Control certificate validation
    ${DisableCertificateValidation},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # password to access Ansible API
    ${Password},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # URL of the Ansible server
    ${Url},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # username to access Ansible API.
    ${Username},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNAnsibleSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Edit OT-IoT asset
.Description
Edit OT-IoT asset
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
System.Boolean
.Link
https://github.com/zeronetworkszn.api/update-znassetot
#>
function Update-ZNAssetOt {
[OutputType([System.Boolean])]
[CmdletBinding(DefaultParameterSetName='PutExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${DisplayName},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Single]
    # .
    ${Type},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            PutExpanded = 'ZN.Api.private\Update-ZNAssetOt_PutExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the Default SSO Application settings in Identity Providers
.Description
Update the Default SSO Application settings in Identity Providers
.Example
Update-ZNDefaultApplicationSetting -Application 2

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-zndefaultapplicationsetting
#>
function Update-ZNDefaultApplicationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # 1-Admin Portal, 2-Access Portal
    ${Application},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNDefaultApplicationSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Firewall settings.
.Description
Returns the properties of the updated Firewall settings.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znfirewallsetting
#>
function Update-ZNFirewallSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # .
    ${ImplicitIcmpRuleEnabled},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNFirewallSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update identity provider settings in Identity Providers
.Description
Update identity provider settings in Identity Providers
.Example
$azure = Get-ZNIdpSetting | where {$_.IdentityProviderType -eq "azure"}
Update-ZNIdpSetting -IdentityProviderId $azure.IdentityProviderType -Certificate $azure.Certificate -IdentityProvider $azure.IdentityProviderType -SloUrl $azure.SloUrl -SsoUrl $azure.SsoUrl -IsDefault

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp
.Link
https://github.com/zeronetworkszn.api/update-znidpsetting
#>
function Update-ZNIdpSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsIdp], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # Identity provider Id
    ${IdentityProviderId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Identity Provider certificate
    ${Certificate},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # .
    ${IdentityProvider},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Set as the default authentication method
    ${IsDefault},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single Log out url
    ${SloUrl},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Single sign on url
    ${SsoUrl},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNIdpSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the upddated properties of JAMF Credentials settings.
.Description
Returns the upddated properties of JAMF Credentials settings.
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials
.Link
https://github.com/zeronetworkszn.api/update-znjamfcredentialssetting
#>
function Update-ZNJamfCredentialsSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsJamfCredentials], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # JAMF url
    ${Host1},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # JAMF Password
    ${Password},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # JAMF username
    ${Username},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNJamfCredentialsSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the linux user settings in Asset Managment
.Description
Update the linux user settings in Asset Managment
.Example
Update-ZNLinuxUserSetting -Username zn-admin -Password "NewPassword" -PrivateKey "Key"

.Outputs
System.String
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znlinuxusersetting
#>
function Update-ZNLinuxUserSetting {
[OutputType([System.String], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # password for the linux user
    ${Password},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # private key for the linux user
    ${PrivateKey},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the linux user name
    ${Username},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNLinuxUserSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns an empty object.
.Description
Returns an empty object.
.Example
$mfa = Get-ZNMfaAuthenticationSetting
Update-ZNMfaAuthenticationSetting -IsRequiresAuth:$mfa.ItemIsRequiresAuth -IsSsoForceAuth:$mfa.ItemIsSsoForceAuth -TokenTtl 120

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znmfaauthenticationsetting
#>
function Update-ZNMfaAuthenticationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IAny], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Authentication Reqiured
    ${IsRequiresAuth},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Force sso authentication
    ${IsSsoForceAuth},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # Token time to tive in minutes
    ${TokenTtl},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNMfaAuthenticationSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated MFA detection settings.
.Description
Returns the properties of the updated MFA detection settings.
.Example
Update-ZNMfaDetectionSetting -TimeoutMinutes 5

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection
.Link
https://github.com/zeronetworkszn.api/update-znmfadetectionsetting
#>
function Update-ZNMfaDetectionSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMfaDetection], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # access policy cooldown
    ${TimeoutMinutes},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNMfaDetectionSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Update the monitored group settings in Asset Managment
.Description
Update the monitored group settings in Asset Managment
.Example
Update-ZNMonitoredGroupSetting -GroupId (Get-ZNMonitoredGroupCandidatesSetting -Search "All AD assets").Items.Id -IsEnabled

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup
.Link
https://github.com/zeronetworkszn.api/update-znmonitoredgroupsetting
#>
function Update-ZNMonitoredGroupSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsMonitoredGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The groupId for monitoring
    ${GroupId},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Enable/Disable monitoring group
    ${IsEnabled},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNMonitoredGroupSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the updated Mail Notifications settings.
.Description
Returns the properties of the updated Mail Notifications settings.
.Example
Update-ZNNotificationSetting -AssetProtected:$true -AssetQueued:$false -AssetUnprotected:$true

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification
.Link
https://github.com/zeronetworkszn.api/update-znnotificationsetting
#>
function Update-ZNNotificationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ISettingsNotification], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Notify asset added to protection
    ${AssetProtected},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Notify asset added to learning
    ${AssetQueued},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # Notify asset removed from protection
    ${AssetUnprotected},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNNotificationSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the properties of the group that was updated for Protection Automation settings.
.Description
Returns the properties of the group that was updated for Protection Automation settings.
.Example
Update-ZNProtectionAutomationSetting -GroupId (Get-ZNAdGroup -Search ZeroNetworksProtectedAssets).Id

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup
.Link
https://github.com/zeronetworkszn.api/update-znprotectionautomationsetting
#>
function Update-ZNProtectionAutomationSetting {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IGroup], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Group ID to set
    ${GroupId},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNProtectionAutomationSetting_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Returns the updated settings for the protection policy.
.Description
Returns the updated settings for the protection policy.
.Example
$pp = Get-ZNProtectionPolicy | where {$_.GroupId -eq "g:t:01276c2c"}
Update-ZNProtectionPolicy -ProtectionPolicyId $pp.Id -MinQueueDays 30

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy
.Link
https://github.com/zeronetworkszn.api/update-znprotectionpolicy
#>
function Update-ZNProtectionPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IProtectionPolicy], [ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # The id of the protection policy
    ${ProtectionPolicyId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # .
    ${MinQueueDays},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.private\Update-ZNProtectionPolicy_UpdateExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set the portal security settings
.Description
Set the portal security settings
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError
.Link
https://github.com/zeronetworkszn.api/update-znsettingsauth
#>
function Update-ZNSettingsAuth {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.IError])]
[CmdletBinding(DefaultParameterSetName='PutExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Single]
    # Portal session token timeout (in minutes)
    ${ItemPortalTokenTtl},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Returns true when the command succeeds
    ${PassThru},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            PutExpanded = 'ZN.Api.private\Update-ZNSettingsAuth_PutExpanded';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Login to Zero Networks to get a token for cmdlet use
.Description
Login to Zero Networks to get a token for cmdlet use

#.Link
https://github.com/zeronetworks/zn.api/connect-zn
.Example
Connect-ZN -UserName user@zeronetworks.com

.Link
https://github.com/zeronetworkszn.api/connect-zn
#>
function Connect-ZN {
[CmdletBinding(PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # login
    ${Email}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\Connect-ZN';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Logout of Zero Networks
.Description
Logout of Zero Networks

#.Link
https://github.com/zeronetworks/zn.api/Disconnect-zn
.Example
Disconnect-ZN 

.Link
https://github.com/zeronetworkszn.api/disconnect-zn
#>
function Disconnect-ZN {
[CmdletBinding(PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param()

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\Disconnect-ZN';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
List the Zero Networks environments
.Description
List the Zero Networks environments

#.Link
https://github.com/zeronetworks/zn.api/get-znenvironment
.Example
Get-ZNEnvironment

.Link
https://github.com/zeronetworkszn.api/get-znenvironment
#>
function Get-ZNEnvironment {
[CmdletBinding(PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param()

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\Get-ZNEnvironment';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Create a in-memory object for PortsList
.Description
Create a in-memory object for PortsList
.Example
$portsList = New-ZNPortsList -Protocol TCP -Ports "44,45"
.Example
$portsList = @()
$tcp = New-ZNPortsList -Protocol TCP -Ports "44"
$udp = New-ZNPortsList -Protocol UDP -Ports "44"
$portsList +=$tcp
$portsList +=$udp
$portsList

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem
.Link
https://github.com/zeronetworks/zn.api/new-znportslist
#>
function New-ZNPortsList {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem])]
[CmdletBinding(PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Protocol
    ${Protocol},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # List of port numbers
    ${Ports}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\New-ZNPortsList';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Create a in-memory object for Simulation Parameters
.Description
Create a in-memory object for Simulation Parameters
.Example
{{ Add code here }}
.Example
{{ Add code here }}

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Components1Tw47WoParametersSimulationparameterSchema
.Link
https://github.com/zeronetworks/zn.api/new-znsimulatemfainboundpolicyparameters
#>
function New-ZNSimulateMFAPolicyParameters {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Components1Tw47WoParametersSimulationparameterSchema])]
[CmdletBinding(PositionalBinding=$false)]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Source Asset
    ${SourceAsset},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Source User
    ${SourceUser},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Destination Asset
    ${DestinationAsset},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Destination Process
    ${Protocol},

    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # Destination Process
    ${Port},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Source Process
    ${SourceProcess},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Destination Process
    ${DestinationProcess}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\New-ZNSimulateMFAPolicyParameters';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Deletes the API key
.Description
Deletes the API Key

#.Link
https://github.com/zeronetworks/zn.api/remove-znapikey
.Example
Remove-ZNApiKey

.Link
https://github.com/zeronetworkszn.api/remove-znapikey
#>
function Remove-ZNApiKey {
[CmdletBinding(PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param()

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\Remove-ZNApiKey';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Set the API key for use in all other cmdlets
.Description
Set the API key for use in all other cmdlets

#.Link
https://github.com/zeronetworks/zn.api/set-znapikey
.Example
Set-ZNApiKey -ApiKey 'myApiKey'

.Link
https://github.com/zeronetworkszn.api/set-znapikey
#>
function Set-ZNApiKey {
[CmdletBinding(PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Api Key
    ${ApiKey}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            __AllParameterSets = 'ZN.Api.custom\Set-ZNApiKey';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Change the Zero Networks environment token
.Description
Change the Zero Networks environment token

#.Link
https://github.com/zeronetworks/zn.api/switch-znenvironment
.Example
$env = Get-ZNEnvironment | where {$_.name -eq 'Zero Networks Demo'}
Switch-ZNEnvironment -EnvironmentId $env.Id

.Link
https://github.com/zeronetworkszn.api/switch-znenvironment
#>
function Switch-ZNEnvironment {
[CmdletBinding(DefaultParameterSetName='Name', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(ParameterSetName='Name', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # Environment Name
    ${EnvironmentName},

    [Parameter(ParameterSetName='EnvironmentId', Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # EnvironmentId
    ${EnvironmentId}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            Name = 'ZN.Api.custom\Switch-ZNEnvironment';
            EnvironmentId = 'ZN.Api.custom\Switch-ZNEnvironment';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates a custom group properties.
.Description
Updates a custom group properties.
.Example
Update-ZNCustomGroup -GroupId g:c:DtglBTHi -Description "updated desccription"

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Group
.Link
https://github.com/zeronetworks/zn.api/update-zncustomgroup
#>
function Update-ZNCustomGroup {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Group])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # groupId to filter on
    ${GroupId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The name to update the custom group to.
    ${Name},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The description for the custom group.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNCustomGroup';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an inbound allow rule.
.Description
Updates an inbound allow rule.
.Example
#Get the Rule
$rule = Get-ZNInboundAllowRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList = (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNInboundAllowRule -RuleId $rule.id -RemoteEntityIdsList $rule.RemoteEntityIdsList

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <PortsListItem[]>: the destination ports and protocols.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworks/zn.api/update-zninboundallowrule
#>
function Update-ZNInboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # rule Id
    ${RuleId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The Destination asset(s).
    ${LocalEntityId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the destination process paths.
    ${LocalProcessesList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # the destination ports and protocols.
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the source asset(s).
    ${RemoteEntityIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # excluded destination asset(s).
    ${ExcludedLocalIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # when the rule should expiry.
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the rule description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNInboundAllowRule';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an inbound block rule.
.Description
Updates an inbound block rule.
.Example
#Get the Rule
$rule = Get-ZNInboundBlockRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList = (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNInboundBlockRule -RuleId $rule.id -RemoteEntityIdsList $rule.RemoteEntityIdsList

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <PortsListItem[]>: the destination ports and protocols.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworks/zn.api/update-zninboundblockrule
#>
function Update-ZNInboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # rule Id
    ${RuleId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The Destination asset(s).
    ${LocalEntityId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the destination process paths.
    ${LocalProcessesList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # the destination ports and protocols.
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the source asset(s).
    ${RemoteEntityIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # excluded destination asset(s).
    ${ExcludedLocalIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # when the rule should expiry.
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the rule description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNInboundBlockRule';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an inbound MFA Policy.
.Description
Updates an inbound MFA Policy.
.Example
#Get the policy
$mfaPolicy = Get-ZNMfaInboundPolicy -ReactivePolicyId e1db180f-e435-498c-ae17-59651f3c3dc3
#add a port
$mfaPolicy.ItemDstPort = $mfaPolicy.ItemDstPort+,",24"
Update-ZNMfaInboundPolicy -ReactivePolicyId $mfaPolicy.ItemId -DstPort $mfaPolicy.ItemDstPort

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <PortsListItem[]>: extra ports to open.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

SRCENTITYINFOS <ReactivePolicyInboundBodySrcEntityInfosItem[]>: source asset(s).
  Id <String>: 

SRCUSERINFOS <ReactivePolicyInboundBodySrcUserInfosItem[]>: source user(s).
  Id <String>: 
.Link
https://github.com/zeronetworks/zn.api/update-znmfainboundpolicy
#>
function Update-ZNMfaInboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicy])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # policy Id
    ${ReactivePolicyId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # extra ports to open.
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # [Parameter(ParameterSetName = 'UpdateExpanded')]
    # [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    # [System.String]
    #  destination asset(s).
    # ${DstEntityInfoId},
    #  destination ports.
    ${DstPort},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # destination processes.
    ${DstProcessNames},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # fallback to logged on user enable/disable.
    ${FallbackToLoggedOnUser},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # MFA methods.
    ${MfaMethods},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # protocol 6 for TCP, 17 for UDP.
    ${ProtocolType},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule expiration.
    ${RuleDuration},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcEntityInfosItem[]]
    # source asset(s).
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # source processes.
    ${SrcProcessNames},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyInboundBodySrcUserInfosItem[]]
    # source user(s).
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the policy state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the policy description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNMfaInboundPolicy';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an outbound MFA Policy.
.Description
Updates an outbound MFA Policy.
.Example
#Get the policy
$mfaPolicy = Get-ZNMfaOutboundPolicy -ReactivePolicyId b307438a-5a02-49a0-a8e3-944c0558f0fe 
#add a port
$mfaPolicy.ItemDstPort = $mfaPolicy.ItemDstPort+,",23"
Update-ZNMfaOutboundPolicy -ReactivePolicyId $mfaPolicy.ItemId -DstEntityInfoId $mfaPolicy.DstEntityInfoId -DstPort $mfaPolicy.ItemDstPort -FallbackToLoggedOnUser:$false -MfaMethods $mfaPolicy.ItemMfaMethods -ProtocolType $mfaPolicy.ItemProtocolType -RuleCreationMode $mfaPolicy.ItemRuleCreationMode -RuleDuration $mfaPolicy.ItemRuleDuration -SrcEntityInfos $mfaPolicy.ItemSrcEntityInfos -SrcProcessNames $mfaPolicy.ItemSrcProcessNames  -SrcUserInfos $mfaPolicy.ItemSrcUserInfos -State $mfaPolicy.ItemState

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicy
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

ADDITIONALPORTSLIST <PortsListItem[]>: extra ports to open.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 

SRCENTITYINFOS <ReactivePolicyOutboundBodySrcEntityInfosItem[]>: source asset(s).
  Id <String>: 

SRCUSERINFOS <ReactivePolicyOutboundBodySrcUserInfosItem[]>: source user(s).
  Id <String>: 
.Link
https://github.com/zeronetworks/zn.api/update-znmfaoutboundpolicy
#>
function Update-ZNMfaOutboundPolicy {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicy])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # policy Id
    ${ReactivePolicyId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # extra ports to open.
    # To construct, see NOTES section for ADDITIONALPORTSLIST properties and create a hash table.
    ${AdditionalPortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # [Parameter(ParameterSetName = 'UpdateExpanded')]
    # [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    # [System.String]
    #  destination asset(s).
    # ${DstEntityInfoId},
    #  destination ports.
    ${DstPort},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Management.Automation.SwitchParameter]
    # [Parameter(ParameterSetName = 'UpdateExpanded')]
    # [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    # [System.String[]]
    #  source processes.
    # ${dstProcessNames},
    #  fallback to logged on user enable/disable.
    ${FallbackToLoggedOnUser},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32[]]
    # MFA methods.
    ${MfaMethods},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # protocol 6 for TCP, 17 for UDP.
    ${ProtocolType},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule expiration.
    ${RuleDuration},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcEntityInfosItem[]]
    # source asset(s).
    # To construct, see NOTES section for SRCENTITYINFOS properties and create a hash table.
    ${SrcEntityInfos},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # source processes.
    ${SrcProcessNames},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.ReactivePolicyOutboundBodySrcUserInfosItem[]]
    # source user(s).
    # To construct, see NOTES section for SRCUSERINFOS properties and create a hash table.
    ${SrcUserInfos},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the policy state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the policy description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNMfaOutboundPolicy';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an outbound allow rule.
.Description
Updates an outbound allow rule.
.Example
#Get the Rule
$rule = Get-ZNOutboundAllowRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList += (Search-ZNAsset -Fqdn fs1.zero.labs)
#Update the rule
Update-ZNOutboundAllowRule -RuleId $rule.id -ExpiresAt $rule.ExpiresAt -LocalEntityId $rule.LocalEntityId -LocalProcessesList $rule.LocalProcessesList -PortsList $rule.PortsList -RemoteEntityIdsList $rule.RemoteEntityIdsList -State $rule.State -Description $rule.Description

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <PortsListItem[]>: the destination ports and protocols.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworks/zn.api/update-znoutboundallowrule
#>
function Update-ZNOutboundAllowRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # rule Id
    ${RuleId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The source asset(s).
    ${LocalEntityId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the source process paths.
    ${LocalProcessesList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # the destination ports and protocols.
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the destination asset(s).
    ${RemoteEntityIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # excluded source entities.
    ${ExcludedLocalIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # when the rule should expiry.
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the rule description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNOutboundAllowRule';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}

<#
.Synopsis
Updates an outbound block rule.
.Description
Updates an outbound block rule.
.Example
#Get the Rule
$rule = Get-ZNOutboundBlockRule | where {$_.Description -eq "Test Rule"}
# add an asset to the source list
$rule.RemoteEntityIdsList += (Invoke-ZNEncodeEntityIP -IP 1.1.1.2)
#Update the rule
Update-ZNOutboundBlockRule -RuleId $rule.id -ExpiresAt $rule.ExpiresAt -LocalEntityId $rule.LocalEntityId -LocalProcessesList $rule.LocalProcessesList -PortsList $rule.PortsList -RemoteEntityIdsList $rule.RemoteEntityIdsList -State $rule.State -Description $rule.Description

.Outputs
ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule
.Notes
COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.

PORTSLIST <PortsListItem[]>: the destination ports and protocols.
  [Ports <String>]: 
  [ProtocolType <Int32?>]: 
.Link
https://github.com/zeronetworks/zn.api/update-znoutboundblockrule
#>
function Update-ZNOutboundBlockRule {
[OutputType([ZeroNetworks.PowerShell.Cmdlets.Api.Models.Rule])]
[CmdletBinding(DefaultParameterSetName='UpdateExpanded', PositionalBinding=$false, SupportsShouldProcess, ConfirmImpact='Medium')]
param(
    [Parameter(Mandatory)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Path')]
    [System.String]
    # rule Id
    ${RuleId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # The source asset(s).
    ${LocalEntityId},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the source process paths.
    ${LocalProcessesList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Models.PortsListItem[]]
    # the destination ports and protocols.
    # To construct, see NOTES section for PORTSLIST properties and create a hash table.
    ${PortsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # the destination asset(s).
    ${RemoteEntityIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String[]]
    # excluded source entities.
    ${ExcludedLocalIdsList},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # the rule state.
    ${State},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.Int32]
    # when the rule should expiry.
    ${ExpiresAt},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Body')]
    [System.String]
    # the rule description.
    ${Description},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command as a job
    ${AsJob},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Wait for .NET debugger to attach
    ${Break},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be appended to the front of the pipeline
    ${HttpPipelineAppend},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.SendAsyncStep[]]
    # SendAsync Pipeline Steps to be prepended to the front of the pipeline
    ${HttpPipelinePrepend},

    [Parameter()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Run the command asynchronously
    ${NoWait},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Uri]
    # The URI for the proxy server to use
    ${Proxy},

    [Parameter(DontShow)]
    [ValidateNotNull()]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.PSCredential]
    # Credentials for a proxy server to use for the remote call
    ${ProxyCredential},

    [Parameter(DontShow)]
    [ZeroNetworks.PowerShell.Cmdlets.Api.Category('Runtime')]
    [System.Management.Automation.SwitchParameter]
    # Use the default credentials for the proxy
    ${ProxyUseDefaultCredentials}
)

begin {
    try {
        $outBuffer = $null
        if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) {
            $PSBoundParameters['OutBuffer'] = 1
        }
        $parameterSet = $PSCmdlet.ParameterSetName

        $mapping = @{
            UpdateExpanded = 'ZN.Api.custom\Update-ZNOutboundBlockRule';
        }
        $cmdInfo = Get-Command -Name $mapping[$parameterSet]
        [ZeroNetworks.PowerShell.Cmdlets.Api.Runtime.MessageAttributeHelper]::ProcessCustomAttributesAtRuntime($cmdInfo, $MyInvocation, $parameterSet, $PSCmdlet)
        $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand(($mapping[$parameterSet]), [System.Management.Automation.CommandTypes]::Cmdlet)
        $scriptCmd = {& $wrappedCmd @PSBoundParameters}
        $steppablePipeline = $scriptCmd.GetSteppablePipeline($MyInvocation.CommandOrigin)
        $steppablePipeline.Begin($PSCmdlet)
    } catch {

        throw
    }
}

process {
    try {
        $steppablePipeline.Process($_)
    } catch {

        throw
    }

}
end {
    try {
        $steppablePipeline.End()

    } catch {

        throw
    }
} 
}
